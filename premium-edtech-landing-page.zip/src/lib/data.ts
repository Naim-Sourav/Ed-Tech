export interface MCQ {
  id: string;
  subject: string;
  examTag: string;
  chapter: string;
  difficulty: "সহজ" | "মাঝারি" | "কঠিন";
  points: number;
  question: string;
  options: string[];
  answer: number;
  explanation: string[];
  reference: string;
  attempts: string;
  accuracy: number;
  comments: number;
}

export const QUESTIONS: MCQ[] = [
  {
    id: "math-08",
    subject: "উচ্চতর গণিত",
    examTag: "এইচএসসি",
    chapter: "বিন্যাস ও সমাবেশ",
    difficulty: "কঠিন",
    points: 25,
    question: "(x − 1/x)⁸ এর বিস্তৃতিতে x-বর্জিত পদটি কততম?",
    options: ["৪র্থ পদ", "৫ম পদ", "৬ষ্ঠ পদ", "মধ্যপদ"],
    answer: 1,
    explanation: [
      "সাধারণ পদ: T(r+1) = ⁸Cᵣ · x⁽⁸⁻ʳ⁾ · (−1/x)ʳ = (−1)ʳ · ⁸Cᵣ · x⁽⁸⁻²ʳ⁾",
      "x-বর্জিত পদের শর্ত: ৮ − ২r = ০ ⟹ r = ৪",
      "সুতরাং x-বর্জিত পদটি = T(4+1) = ৫ম পদ",
    ],
    reference: "এইচএসসি উচ্চতর গণিত ১ম পত্র — অধ্যায় ৭ (থার্ড এডিশন, পৃ. ২৮৪)",
    attempts: "৩২,৪০৮",
    accuracy: 41,
    comments: 218,
  },
  {
    id: "bio-01",
    subject: "জীববিজ্ঞান",
    examTag: "মেডিকেল ভর্তি",
    chapter: "কোষ ও টিস্যু",
    difficulty: "সহজ",
    points: 10,
    question: "জীবদেহের গঠন ও কাজের একককে কী বলে?",
    options: ["টিস্যু", "কোষ", "অঙ্গ", "অঙ্গতন্ত্র"],
    answer: 1,
    explanation: [
      "কোষ (Cell) হলো প্রাণদেহের গঠনগত ও কার্যকরী মৌলিক একক।",
      "১৮৩৮ সালে স্লাইডেন ও সোয়ান কোষ তত্ত্ব (Cell Theory) প্রতিপাদন করেন।",
      "সব প্রাণীই এক বা একাধিক কোষ দিয়ে গঠিত এবং জীবনের সকল প্রাণক্রিয়া কোষের ভেতরেই সংঘটিত হয়।",
    ],
    reference: "এইচএসসি জীববিজ্ঞান ১ম পত্র — অধ্যায় ১ (পৃ. ২৩)",
    attempts: "৮৯,১২০",
    accuracy: 93,
    comments: 104,
  },
  {
    id: "en-idiom",
    subject: "English",
    examTag: "বিসিএস",
    chapter: "Idioms & Phrases",
    difficulty: "মাঝারি",
    points: 15,
    question: "The correct meaning of the idiom “To make ends meet” is—",
    options: [
      "To start a new job",
      "To live within one's income",
      "To unite two people",
      "To increase expenses",
    ],
    answer: 1,
    explanation: [
      "“To make ends meet” অর্থাৎ কোনোভাবে আয়-ব্যয় মেলানো / সীমিত আয়ের মধ্যে সংসার চালানো।",
      "Example: He works two jobs just to make ends meet.",
      "বিসিএস ৩৪–৪৬তম প্রিলির একাধিক প্রশ্নে এই ইডিয়ম এসেছে।",
    ],
    reference: "BCS Preliminary Digest — Idioms & Phrases (পৃ. ৭৬)",
    attempts: "৫৪,৬৩২",
    accuracy: 67,
    comments: 342,
  },
  {
    id: "bn-opp",
    subject: "বাংলা ব্যাকরণ",
    examTag: "NTRCA",
    chapter: "বিপরীত শব্দ",
    difficulty: "সহজ",
    points: 10,
    question: "‘সৌম্য’ শব্দের বিপরীত শব্দ কোনটি?",
    options: ["শান্ত", "উগ্র", "মৃদু", "সুন্দর"],
    answer: 1,
    explanation: [
      "‘সৌম্য’ অর্থ মৃদুভাবী বা শান্তস্বভাব; এর বিপরীতার্থক শব্দ ‘উগ্র’।",
      "‘শান্ত’ ও ‘মৃদু’ সমার্থক, এবং ‘সুন্দর’ প্রাসঙ্গিক নয়।",
      "শিবির অনুশীলনী ২০২৪ ও NTRCA ১৫–১৮তম তে এ ধাঁচের প্রশ্ন পুনরাবৃত্ত হয়েছে।",
    ],
    reference: "বাংলা ভাষা ও সাহিত্য গাইড — শব্দভাণ্ডার (পৃ. ১৫২)",
    attempts: "৬১,০৫৪",
    accuracy: 88,
    comments: 97,
  },
];

export interface Topper {
  name: string;
  meta: string;
  points: string;
  correct: number;
  grad: string;
}

export const TOPPERS: Topper[] = [
  { name: "তানভীর আহমেদ", meta: "বিসিএস প্রস্তুতি", points: "৯,৮৪৫", correct: 92, grad: "from-brand-500 to-amber-500" },
  { name: "নুসরাত জাহান", meta: "ঢাবি ‘ক’ পূর্ণাঙ্গ চর্চা", points: "৯,২১৭", correct: 89, grad: "from-amber-400 to-orange-500" },
  { name: "রাফসান চৌধুরী", meta: "ব্যাংক জব", points: "৮,৯৬৪", correct: 87, grad: "from-amber-500 to-orange-500" },
  { name: "মেহজাবিন রহমান", meta: "NTRCA ১৮তম", points: "৮,৭০৩", correct: 86, grad: "from-emerald-500 to-teal-500" },
  { name: "সাইফুল ইসলাম", meta: "প্রাথমিক সহ. শিক্ষক", points: "৮,১১০", correct: 84, grad: "from-rose-500 to-orange-500" },
];

export const EXAM_STRIP = [
  "বিসিএস প্রিলি",
  "ব্যাংক জব",
  "প্রাথমিক সহকারী শিক্ষক",
  "NTRCA",
  "ঢাবি · চাউই ‘ক‑ক’ ইউনিট",
  "মেডিকেল ভর্তি",
  "বুয়েট প্রস্তুতি",
  "রেলওয়ে নিয়োগ",
  "NSI ও ডাক বিভাগ",
  "এইচএসসি একাডেমিক",
  "ক্যাডার কোচিং",
  "প্রাইমারি ফাইনাল",
];
