import Benefits from "./components/Benefits";
import CTA from "./components/CTA";
import FAQ from "./components/FAQ";
import Features from "./components/Features";
import Footer from "./components/Footer";
import Hero from "./components/Hero";
import Navbar from "./components/Navbar";
import Pricing from "./components/Pricing";
import Showcase from "./components/Showcase";
import Testimonials from "./components/Testimonials";
import Trust from "./components/Trust";

export default function App() {
  return (
    <div className="min-h-screen overflow-x-clip bg-[#FAFAF9] font-sans text-ink-950 antialiased">
      <Navbar />
      <main>
        <Hero />
        <Trust />
        <Features />
        <Showcase />
        <Benefits />
        <Testimonials />
        <Pricing />
        <FAQ />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
