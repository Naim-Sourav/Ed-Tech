/**
 * Porikkhangon brand mark — black tile with a white "?" curl
 * completed by the signature orange dot (#FF5200).
 */
export default function LogoMark({ className = "size-10" }: { className?: string }) {
  return (
    <span className={`relative inline-grid place-items-center overflow-hidden rounded-2xl bg-ink-950 shadow-lg shadow-brand-500/25 ${className}`} aria-label="পরীক্ষাঙ্গন লোগো" role="img">
      <svg viewBox="0 0 44 44" className="size-[86%]" fill="none" aria-hidden>
        <path
          d="M13.5 15.8C14 11.6 17.5 8.6 22 8.6c4.9 0 8.5 3.2 8.1 7.7-.4 4.1-3.4 5.2-6 6.8-2.4 1.4-3.2 2.4-3.2 4.9v2.2"
          stroke="#fff"
          strokeWidth="4.6"
          strokeLinecap="round"
        />
        <circle cx="20.9" cy="35.4" r="4" fill="#FF5200" />
      </svg>
    </span>
  );
}
