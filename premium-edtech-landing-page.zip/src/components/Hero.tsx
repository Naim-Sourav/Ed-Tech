import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import {
  ArrowRight,
  BadgeCheck,
  Bookmark,
  Check,
  ChevronRight,
  Clock3,
  Flame,
  Lightbulb,
  Play,
  Share2,
  Star,
  Target,
  X,
  Zap,
} from "lucide-react";
import { useState, type MouseEvent } from "react";
import { QUESTIONS } from "../lib/data";
import { EASE, toBn } from "../lib/helpers";

const LETTERS = ["ক", "খ", "গ", "ঘ"];

/* ------------------------------------------------------------------ */
/*  Interactive mini question card (hero demo)                          */
/* ------------------------------------------------------------------ */
function HeroQuestionCard() {
  const [qIndex, setQIndex] = useState(1); // start with biology
  const [picked, setPicked] = useState<number | null>(null);
  const q = QUESTIONS[qIndex % QUESTIONS.length];
  const answered = picked !== null;
  const isCorrect = picked === q.answer;

  const next = () => {
    setPicked(null);
    setQIndex((v) => (v + 1) % QUESTIONS.length);
  };

  return (
    <div className="relative">
      {/* glow behind card */}
      <div className="absolute -inset-6 -z-10 rounded-[2.5rem] bg-gradient-to-br from-brand-400/35 via-amber-400/20 to-gold-400/30 blur-2xl" />

      <div className="ring-conic relative overflow-hidden rounded-[1.75rem] border border-white/70 bg-white/90 backdrop-blur-xl">
        {/* top strip */}
        <div className="flex items-center justify-between gap-2 border-b border-ink-100/80 bg-gradient-to-r from-brand-50/80 to-transparent px-5 py-3.5">
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-brand-600 px-3 py-1 text-xs font-bold text-white shadow-sm shadow-brand-500/40">
              {q.examTag}
            </span>
            <span className="hidden rounded-full bg-white px-3 py-1 text-xs font-semibold text-ink-600 ring-1 ring-ink-200/70 sm:inline">
              {q.subject} · {q.chapter}
            </span>
          </div>
          <div className="flex items-center gap-3 text-ink-500">
            <span className="inline-flex items-center gap-1 text-xs font-bold text-gold-600">
              <Zap className="size-3.5 fill-gold-400 text-gold-500" /> {toBn(q.points)} পয়েন্ট
            </span>
            <button aria-label="বুকমার্ক" className="transition hover:text-brand-600">
              <Bookmark className="size-4" />
            </button>
            <button aria-label="শেয়ার" className="transition hover:text-brand-600">
              <Share2 className="size-4" />
            </button>
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={q.id}
            initial={{ opacity: 0, x: 32 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -32 }}
            transition={{ duration: 0.45, ease: EASE }}
            className="p-5 sm:p-6"
          >
            <p className="font-display text-[1.15rem] font-semibold leading-relaxed text-ink-900 sm:text-xl">
              {q.question}
            </p>

            {/* options */}
            <div className="mt-5 grid gap-2.5" role="radiogroup" aria-label="উত্তর নির্বাচন">
              {q.options.map((opt, i) => {
                const isPicked = picked === i;
                const isAns = i === q.answer;
                let cls =
                  "border-ink-200/90 bg-white hover:border-brand-400 hover:bg-brand-50/60 hover:shadow-md hover:shadow-brand-500/10";
                if (answered && isAns)
                  cls = "border-emerald-500 bg-emerald-50 shadow-md shadow-emerald-500/15";
                else if (answered && isPicked && !isAns)
                  cls = "border-rose-400 bg-rose-50";
                else if (answered) cls = "border-ink-200/70 bg-white opacity-55";

                return (
                  <motion.button
                    key={opt}
                    onClick={() => !answered && setPicked(i)}
                    disabled={answered}
                    whileTap={!answered ? { scale: 0.98 } : undefined}
                    animate={answered && isPicked && !isAns ? { x: [0, -7, 7, -4, 4, 0] } : {}}
                    transition={{ duration: 0.4 }}
                    className={`group flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition-all duration-300 ${cls}`}
                    role="radio"
                    aria-checked={isPicked}
                  >
                    <span
                      className={`grid size-8 shrink-0 place-items-center rounded-xl text-sm font-bold transition-colors duration-300 ${
                        answered && isAns
                          ? "bg-emerald-500 text-white"
                          : answered && isPicked && !isAns
                            ? "bg-rose-500 text-white"
                            : "bg-ink-100 text-ink-600 group-hover:bg-brand-100 group-hover:text-brand-700"
                      }`}
                    >
                      {answered && isAns ? <Check className="size-4" strokeWidth={3} /> : answered && isPicked && !isAns ? <X className="size-4" strokeWidth={3} /> : LETTERS[i]}
                    </span>
                    <span className="text-[15px] font-medium text-ink-800">{opt}</span>
                    {answered && isAns && isPicked && (
                      <motion.span
                        initial={{ scale: 0, rotate: -20 }}
                        animate={{ scale: 1, rotate: 0 }}
                        transition={{ type: "spring", stiffness: 400, damping: 16 }}
                        className="ml-auto inline-flex items-center gap-1 rounded-full bg-emerald-500 px-2.5 py-1 text-xs font-bold text-white shadow-md shadow-emerald-500/40"
                      >
                        +{toBn(q.points)}
                      </motion.span>
                    )}
                  </motion.button>
                );
              })}
            </div>

            {/* explanation */}
            <AnimatePresence>
              {answered && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.55, ease: EASE }}
                  className="overflow-hidden"
                >
                  <div
                    className={`mt-4 rounded-2xl border p-4 ${
                      isCorrect ? "border-emerald-200 bg-emerald-50/60" : "border-amber-200 bg-amber-50/70"
                    }`}
                  >
                    <p className={`flex items-center gap-2 text-sm font-bold ${isCorrect ? "text-emerald-700" : "text-amber-700"}`}>
                      <Lightbulb className="size-4" />
                      {isCorrect ? "অসাধারণ! সঠিক উত্তর" : "ব্যাখ্যা দেখো — পরেরটা সঠিক হবেই"}
                    </p>
                    <p className="mt-2 text-[13.5px] leading-relaxed text-ink-700">{q.explanation[0]}</p>
                    <p className="mt-1.5 text-xs text-ink-500">
                      <span className="font-semibold text-ink-600">রেফারেন্স:</span> {q.reference}
                    </p>
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <p className="text-xs font-medium text-ink-500">
                      {toBn(q.accuracy)}% শিক্ষার্থী সঠিক উত্তর দিয়েছে
                    </p>
                    <button
                      onClick={next}
                      className="group inline-flex items-center gap-1.5 rounded-full bg-ink-950 px-4 py-2 text-sm font-bold text-white transition hover:bg-brand-600"
                    >
                      পরের প্রশ্ন
                      <ChevronRight className="size-4 transition-transform group-hover:translate-x-0.5" />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {!answered && (
              <div className="mt-4 flex items-center justify-between text-xs font-medium text-ink-500">
                <span className="inline-flex items-center gap-1.5">
                  <Clock3 className="size-3.5" /> গড় সমাধান সময় ০:৩৮ সে.
                </span>
                <span>{q.attempts} বার সমাধান করা হয়েছে</span>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Floating parallax chip                                              */
/* ------------------------------------------------------------------ */
function FloatChip({
  className,
  depth,
  mx,
  my,
  icon,
  title,
  sub,
  delay,
}: {
  className: string;
  depth: number;
  mx: ReturnType<typeof useSpring>;
  my: ReturnType<typeof useSpring>;
  icon: React.ReactNode;
  title: string;
  sub: string;
  delay: number;
}) {
  const x = useTransform(mx, (v) => v * depth);
  const y = useTransform(my, (v) => v * depth);
  return (
    <motion.div
      style={{ x, y }}
      initial={{ opacity: 0, scale: 0.6, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ delay, duration: 0.8, ease: EASE }}
      className={`absolute z-20 ${className}`}
    >
      <div className="animate-float glass flex items-center gap-2.5 rounded-2xl border border-white/70 px-3.5 py-2.5 shadow-xl shadow-brand-500/15">
        <span className="grid size-9 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-md shadow-brand-500/30">
          {icon}
        </span>
        <span>
          <span className="block text-[13px] font-bold leading-tight text-ink-900">{title}</span>
          <span className="block text-[11.5px] font-medium leading-tight text-ink-500">{sub}</span>
        </span>
      </div>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  Hero                                                                */
/* ------------------------------------------------------------------ */
export default function Hero() {
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const mx = useSpring(rawX, { stiffness: 60, damping: 18 });
  const my = useSpring(rawY, { stiffness: 60, damping: 18 });

  const onMove = (e: MouseEvent<HTMLElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    rawX.set(((e.clientX - r.left) / r.width - 0.5) * 28);
    rawY.set(((e.clientY - r.top) / r.height - 0.5) * 28);
  };

  return (
    <section id="top" onMouseMove={onMove} className="relative overflow-hidden pb-16 pt-32 sm:pt-40 lg:pb-24">
      {/* ambient background */}
      <div className="dot-grid absolute inset-0 -z-20 [mask-image:radial-gradient(75%_60%_at_50%_35%,black,transparent)]" />
      <div className="animate-pulse-soft absolute -left-40 top-24 -z-10 size-[34rem] rounded-full bg-brand-300/35 blur-3xl" />
      <div className="animate-pulse-soft absolute -right-48 top-72 -z-10 size-[30rem] rounded-full bg-amber-300/30 blur-3xl [animation-delay:1.4s]" />
      <div className="animate-pulse-soft absolute left-1/3 top-[38rem] -z-10 size-[26rem] rounded-full bg-gold-300/30 blur-3xl [animation-delay:2.6s]" />
      <div className="animate-spin-slow absolute -right-24 -top-24 -z-10 size-96 rounded-full border border-dashed border-brand-300/50" />

      <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:gap-8">
        {/* ------------ copy ------------ */}
        <div className="text-center lg:text-left">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: EASE }}
            className="inline-flex items-center gap-2 rounded-full border border-brand-500/25 bg-white/80 py-1.5 pl-1.5 pr-4 text-sm font-semibold text-brand-700 shadow-sm backdrop-blur"
          >
            <span className="rounded-full bg-gradient-to-r from-brand-600 to-amber-500 px-2.5 py-0.5 text-xs font-bold text-white">
              নতুন
            </span>
            লাইভ মক টেস্ট ও র‍্যাংকিং এখন চালু
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 34, filter: "blur(8px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ duration: 1, delay: 0.12, ease: EASE }}
            className="font-display mt-6 text-[2.6rem] font-bold leading-[1.08] tracking-tight text-ink-950 sm:text-6xl lg:text-[4.15rem]"
          >
            প্রতিটি প্রশ্নে <span className="text-gradient">পরিষ্কার ব্যাখ্যা</span>,
            <br className="hidden sm:block" /> প্রতিটি দিনে{" "}
            <span className="relative inline-block">
              আত্মবিশ্বাস
              <svg viewBox="0 0 220 14" className="absolute -bottom-1.5 left-0 w-full" fill="none" aria-hidden>
                <motion.path
                  d="M4 10 C 60 2, 160 2, 216 8"
                  stroke="#ffb020"
                  strokeWidth="5"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 1.1, delay: 0.9, ease: EASE }}
                />
              </svg>
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.28, ease: EASE }}
            className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-ink-600 lg:mx-0"
          >
            বিসিএস, ব্যাংক, প্রাথমিক, NTRCA থেকে ঢাবি ও মেডিকেল ভর্তি —{" "}
            <span className="font-semibold text-ink-800">৫০,০০০+ নির্ভুল প্রশ্ন</span> অধ্যায়ভিত্তিক চর্চা,
            বই-রেফারেন্সসহ ব্যাখ্যা আর রিয়েল-টাইম মেধাতালিকায়। পাশের কার্ডের প্রশ্নটা এখনই সলভ করে দেখো!
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.42, ease: EASE }}
            className="mt-9 flex flex-col items-center gap-4 sm:flex-row lg:justify-start sm:justify-center"
          >
            <a
              href="#cta"
              className="btn-shine group inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-brand-600 to-brand-500 px-8 py-4 text-base font-bold text-white shadow-xl shadow-brand-500/35 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-brand-500/50 sm:w-auto"
            >
              ফ্রিতে চর্চা শুরু করো
              <ArrowRight className="size-5 transition-transform duration-300 group-hover:translate-x-1.5" />
            </a>
            <a
              href="#showcase"
              className="group inline-flex w-full items-center justify-center gap-3 rounded-full border border-ink-200 bg-white/80 px-7 py-4 text-base font-bold text-ink-800 backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:border-brand-300 hover:text-brand-700 hover:shadow-lg sm:w-auto"
            >
              <span className="grid size-9 place-items-center rounded-full bg-ink-950 text-white transition-colors duration-300 group-hover:bg-brand-600">
                <Play className="size-4 fill-current" />
              </span>
              প্রশ্ন দেখে বুঝো
            </a>
          </motion.div>

          {/* social proof */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.56, ease: EASE }}
            className="mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-4 lg:justify-start"
          >
            <div className="flex -space-x-3">
              {[
                ["তা", "from-brand-500 to-brand-700"],
                ["নু", "from-amber-400 to-orange-600"],
                ["রা", "from-orange-500 to-red-500"],
                ["মে", "from-emerald-500 to-teal-600"],
                ["সা", "from-rose-400 to-rose-600"],
              ].map(([ch, grad], i) => (
                <span
                  key={ch}
                  className={`grid size-10 place-items-center rounded-full border-2 border-white bg-gradient-to-br ${grad} text-sm font-bold text-white shadow-md`}
                  style={{ zIndex: 5 - i }}
                >
                  {ch}
                </span>
              ))}
            </div>
            <div className="text-left">
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="size-4 fill-gold-400 text-gold-400" />
                ))}
                <span className="ml-1 text-sm font-bold text-ink-900">৪.৯/৫</span>
              </div>
              <p className="text-sm font-medium text-ink-500">২,৩৪,০০০+ শিক্ষার্থীর ভরসার নাম</p>
            </div>
            <div className="hidden items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3.5 py-1.5 sm:flex">
              <BadgeCheck className="size-4 text-emerald-600" />
              <span className="text-sm font-bold text-emerald-700">৯২% প্রশ্ন বোর্ড-সিলেবাস মিলিয়ে যাচাইকৃত</span>
            </div>
          </motion.div>
        </div>

        {/* ------------ interactive demo ------------ */}
        <motion.div
          initial={{ opacity: 0, y: 48, scale: 0.94 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 1.1, delay: 0.35, ease: EASE }}
          className="relative mx-auto w-full max-w-md lg:max-w-none"
        >
          <HeroQuestionCard />
          <FloatChip
            className="-left-4 -top-7 sm:-left-10"
            depth={1.2}
            mx={mx}
            my={my}
            icon={<Flame className="size-4.5" />}
            title="১২ দিনের স্ট্রিক"
            sub="ধারাবাহিকতাই সাফল্য"
            delay={0.85}
          />
          <FloatChip
            className="-right-3 top-1/3 sm:-right-8"
            depth={-1}
            mx={mx}
            my={my}
            icon={<Target className="size-4.5" />}
            title="লক্ষ্য: দৈনিক ৫০ প্রশ্ন"
            sub="৩২টি সম্পন্ন"
            delay={1}
          />
          <FloatChip
            className="-bottom-7 left-8"
            depth={0.8}
            mx={mx}
            my={my}
            icon={<Zap className="size-4.5" />}
            title="+২৫ পয়েন্ট"
            sub="সঠিক উত্তরে রিওয়ার্ড"
            delay={1.15}
          />
        </motion.div>
      </div>
    </section>
  );
}
