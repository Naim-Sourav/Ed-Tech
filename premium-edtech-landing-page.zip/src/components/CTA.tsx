import { motion } from "framer-motion";
import { Apple, ArrowRight, Heart, Play, ShieldCheck, Sparkles } from "lucide-react";
import { Reveal } from "../lib/helpers";

export default function CTA() {
  return (
    <section id="cta" className="relative px-4 pb-24 pt-6 sm:px-6" aria-label="শুরু করুন">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="noise relative overflow-hidden rounded-[2.5rem] bg-ink-950 px-6 py-16 text-center text-white sm:px-12 sm:py-24">
            {/* ambience */}
            <div className="dot-grid-dark absolute inset-0 opacity-60" />
            <div className="absolute -left-24 -top-28 size-96 rounded-full bg-brand-600/45 blur-3xl" />
            <div className="absolute -bottom-32 -right-16 size-[26rem] rounded-full bg-amber-600/35 blur-3xl" />
            <div className="absolute left-1/2 top-1/2 size-[30rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-brand-500/15 blur-3xl" />
            <motion.span
              animate={{ y: [0, -14, 0], rotate: [0, 14, 0] }}
              transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
              className="absolute left-[12%] top-[18%] text-gold-400/70"
            >
              <Sparkles className="size-8" />
            </motion.span>
            <motion.span
              animate={{ y: [0, 12, 0], rotate: [0, -12, 0] }}
              transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1.2 }}
              className="absolute right-[14%] top-[24%] text-brand-300/70"
            >
              <Sparkles className="size-6" />
            </motion.span>
            <motion.span
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 0.6 }}
              className="absolute bottom-[20%] right-[22%] text-amber-300/60"
            >
              <Sparkles className="size-5" />
            </motion.span>

            <div className="relative">
              <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-sm font-semibold text-brand-200 backdrop-blur">
                <ShieldCheck className="size-4 text-emerald-400" /> কোনো কার্ড লাগে না · ৩০ সেকেন্ডে সাইন আপ
              </span>

              <h2 className="font-display mx-auto mt-7 max-w-3xl text-4xl font-bold leading-[1.12] tracking-tight sm:text-6xl">
                আজই প্রথম প্রশ্নটা সলভ করো —
                <br />
                <span className="text-gradient-dark">চাকরিটা তোমার অপেক্ষায়</span>
              </h2>
              <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-white/60">
                ২,৩৪,০০০+ শিক্ষার্থী প্রতিদিন সকালে পরীক্ষাঙ্গন খুলে। আজ থেকেই তুমি আর একা নও — পুরো কমিউনিটি তোমার সাথে।
              </p>

              <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <a
                  href="#top"
                  className="btn-shine group inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-gradient-to-r from-brand-500 to-amber-500 px-9 py-4.5 text-lg font-bold text-white shadow-2xl shadow-brand-500/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-brand-400/60 sm:w-auto"
                >
                  ফ্রি অ্যাকাউন্ট খোলো
                  <ArrowRight className="size-5 transition-transform duration-300 group-hover:translate-x-1.5" />
                </a>
                <div className="flex gap-3">
                  <a
                    href="#top"
                    className="group flex items-center gap-2.5 rounded-2xl border border-white/12 bg-white/5 px-5 py-3 backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:border-white/25 hover:bg-white/10"
                  >
                    <Play className="size-6 fill-white text-white" />
                    <span className="text-left leading-tight">
                      <span className="block text-[10px] font-medium uppercase tracking-wider text-white/50">Download on</span>
                      <span className="block text-sm font-bold">Google Play</span>
                    </span>
                  </a>
                  <a
                    href="#top"
                    className="group flex items-center gap-2.5 rounded-2xl border border-white/12 bg-white/5 px-5 py-3 backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:border-white/25 hover:bg-white/10"
                  >
                    <Apple className="size-6 fill-white text-white" />
                    <span className="text-left leading-tight">
                      <span className="block text-[10px] font-medium uppercase tracking-wider text-white/50">Coming soon on</span>
                      <span className="block text-sm font-bold">App Store</span>
                    </span>
                  </a>
                </div>
              </div>

              <p className="mt-9 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm font-semibold text-white/45">
                <span>★ ৪.৯ — গুগল প্লে রেটিং</span>
                <span className="hidden size-1 rounded-full bg-white/25 sm:block" />
                <span>দৈনিক ২৫ প্রশ্ন চিরকাল ফ্রি</span>
                <span className="hidden size-1 rounded-full bg-white/25 sm:block" />
                <span className="inline-flex items-center gap-1.5">
                  <Heart className="size-4 fill-rose-400 text-rose-400" /> বাংলাদেশে তৈরি, বাংলাদেশের জন্য
                </span>
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
