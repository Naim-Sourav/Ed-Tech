import { Quote, Star } from "lucide-react";
import { Reveal, SectionTag } from "../lib/helpers";

interface TM {
  quote: string;
  name: string;
  org: string;
  grad: string;
}

const ROW_A: TM[] = [
  {
    quote: "প্রিলির বেশিরভাগ প্রশ্নই আগে থেকে চেনা ছিল। অধ্যায়ভিত্তিক সেট আর ব্যাখ্যার বই-রেফারেন্সই আমার গেম-চেঞ্জার — গাইডের ভুল উত্তরে আর কোনোদিন ধোঁকা খাইনি।",
    name: "শারমিন আক্তার",
    org: "৪৬তম বিসিএস — প্রশাসন ক্যাডার",
    grad: "from-amber-500 to-brand-700",
  },
  {
    quote: "বইয়ের ভুল উত্তর নিয়ে আগে চিরদুশ্চিন্তায় থাকতাম। এখানে প্রতিটা প্রশ্ন যাচাই করা, রেফারেন্সসহ — সেই ভরসাতেই নিজ জেলায় প্রথম সারিতে সুপারিশ পেলাম।",
    name: "সাইফুল্লাহ প্রধান",
    org: "প্রাথমিক সহকারী শিক্ষক নিয়োগ, কুমিল্লা",
    grad: "from-amber-400 to-orange-600",
  },
  {
    quote: "শুক্রবারের লাইভ এক্সামের মেধাতালিকাটাই আমার আসল প্রতিযোগিতা। র‍্যাংক নামলে সারা সপ্তাহ আমাকে তাড়া করে — এই তাড়নাটাই ঢাবি ‘ক’ ইউনিটের চান্স এনে দিলো।",
    name: "রাফসান চৌধুরী",
    org: "ঢাকা বিশ্ববিদ্যালয়, ‘ক’ ইউনিট",
    grad: "from-amber-500 to-orange-600",
  },
  {
    quote: "পরীক্ষার আগের রাতে আর ছয়শো পৃষ্ঠার বই ওলটাই না — ভুল বুকের ৮২টা প্রশ্নই রিভাইজ করে ঢুকি। নিজের দুর্বলতা জানাটাই সবচেয়ে বড় প্রস্তুতি।",
    name: "মেহজাবিন রহমান",
    org: "NTRCA ১৮তম — র‍্যাংক ১২",
    grad: "from-emerald-500 to-teal-600",
  },
];

const ROW_B: TM[] = [
  {
    quote: "মেডিকেল ভর্তিতে গতিই সব। প্রতিটা প্রশ্নে গড় সমাধান-সময় দেখায়, তাই কোন চ্যাপ্টারে ধীমান সেটা চিনে টাইম ম্যানেজমেন্ট নিখুঁত করতে পেরেছি।",
    name: "তানিয়া সুলতানা",
    org: "ময়মনসিংহ মেডিকেল কলেজ",
    grad: "from-rose-500 to-orange-500",
  },
  {
    quote: "চাকরির পাশাপাশি পড়ি, সময় পাই শুধু বাসে-রাস্তায়। অফলাইন সেট নামিয়ে প্রতিদিন ৩০টা করে প্রশ্ন সলভ করতাম — প্রথম চেষ্টাতেই লিখিত উত্তীর্ণ।",
    name: "জাকারিয়া হোসেন",
    org: "জনতা ব্যাংক — সিনিয়র অফিসার",
    grad: "from-brand-500 to-brand-700",
  },
  {
    quote: "কোচিংয়ের খরচ জোগানোর সামর্থ্য ছিল না। মাসে ১৯৯ টাকার এই প্ল্যানটাই শহরের মেধাবীদের সমান প্রস্তুতি দিয়েছে — ব্যাখ্যা এত সুন্দর যে আলাদা নোটই লাগে না।",
    name: "নুসরাত জাহান",
    org: "চট্টগ্রাম বিশ্ববিদ্যালয়, ‘খ’ ইউনিট",
    grad: "from-teal-500 to-emerald-600",
  },
  {
    quote: "স্ট্রিক ভাঙা যাবে না — এই লড়াইটাই এখন আমার দৈনিক উৎসাহ। ১৪০ দিন ধরে চর্চা করছি; পরীক্ষা এখনো দূরে হলেও অ্যানালিটিক্স বলে দিচ্ছে, আমি রেডি।",
    name: "আরিফুল ইসলাম",
    org: "বুয়েট অ্যাডমিশন প্রাপ্ত",
    grad: "from-orange-500 to-red-500",
  },
];

function TCard({ t }: { t: TM }) {
  return (
    <figure className="card-shine group relative mx-2.5 w-[21rem] shrink-0 rounded-3xl border border-ink-100 bg-white p-6 shadow-sm transition-all duration-500 hover:-translate-y-1.5 hover:border-brand-300 hover:shadow-xl hover:shadow-brand-500/15 sm:w-[24rem]">
      <Quote className="absolute right-6 top-6 size-8 text-brand-100 transition-colors duration-500 group-hover:text-brand-200" />
      <div className="flex gap-1">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star key={i} className="size-4 fill-gold-400 text-gold-400" />
        ))}
      </div>
      <blockquote className="mt-4 min-h-[7.5rem] text-[14.5px] leading-relaxed text-ink-700">“{t.quote}”</blockquote>
      <figcaption className="mt-5 flex items-center gap-3 border-t border-ink-100 pt-4">
        <span className={`grid size-11 place-items-center rounded-2xl bg-gradient-to-br ${t.grad} font-display text-base font-bold text-white shadow-md`}>
          {t.name.slice(0, 1)}
        </span>
        <span>
          <span className="block text-[15px] font-bold text-ink-900">{t.name}</span>
          <span className="block text-[12.5px] font-medium text-ink-500">{t.org}</span>
        </span>
      </figcaption>
    </figure>
  );
}

function Row({ items, reverse }: { items: TM[]; reverse?: boolean }) {
  return (
    <div className="flex w-max">
      <div className={`flex ${reverse ? "animate-marquee-slow marquee-reverse" : "animate-marquee-slow"}`}>
        {[...items, ...items].map((t, i) => (
          <TCard key={`${t.name}-${i}`} t={t} />
        ))}
      </div>
    </div>
  );
}

export default function Testimonials() {
  return (
    <section id="reviews" className="relative overflow-hidden py-20 sm:py-28" aria-label="শিক্ষার্থীদের মতামত">
      <div className="absolute inset-x-0 top-0 -z-10 h-72 bg-gradient-to-b from-brand-50/80 to-transparent" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <SectionTag icon={<Star className="size-4 fill-current" />} label="সাক্ষাৎ সাফল্য" />
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="font-display mt-5 text-4xl font-bold leading-[1.15] tracking-tight text-ink-950 sm:text-5xl">
              যারা জিতেছে, <span className="text-gradient">তারাই বলছে</span>
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-5 text-lg leading-relaxed text-ink-600">
              গ্রামের স্কুল থেকে ঢাকার ক্যাম্পাস — লক্ষ লক্ষ প্রস্তুতিকারীর দৈনিক সঙ্গী।
            </p>
          </Reveal>
        </div>
      </div>

      <Reveal delay={0.15} className="marquee-paused mt-14">
        <div className="space-y-5 [mask-image:linear-gradient(90deg,transparent,black_6%,black_94%,transparent)]">
          <Row items={ROW_A} />
          <Row items={ROW_B} reverse />
        </div>
      </Reveal>
    </section>
  );
}
