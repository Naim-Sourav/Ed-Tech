import { AnimatePresence, motion } from "framer-motion";
import { Check, Crown, Gem, School, ShieldCheck, Wallet } from "lucide-react";
import { useState } from "react";
import { EASE, Reveal, SectionTag, Stagger, StaggerItem, toBn } from "../lib/helpers";

const PLANS = [
  {
    icon: Gem,
    name: "স্টার্টার",
    tagline: "যারা একদম শুরু করছে",
    monthly: 0,
    yearly: 0,
    cta: "ফ্রি অ্যাকাউন্ট খোলো",
    features: [
      "দৈনিক ২৫টি প্রশ্ন সলভ",
      "বেসিক ব্যাখ্যা ও উত্তর",
      "মাসে ২টি স্যাম্পল মক",
      "কমিউনিটি আলোচনা অ্যাকসেস",
      "বেসিক স্ট্যাটস",
    ],
    featured: false,
  },
  {
    icon: Crown,
    name: "প্রিমিয়াম",
    tagline: "সিরিয়াস প্রস্তুতিকারীর পূর্ণ অস্ত্রাগার",
    monthly: 199,
    yearly: 124,
    yearlyTotal: "৳১,৪৯৯/বছর",
    cta: "প্রিমিয়াম নাও — ৭ দিন ফ্রি",
    features: [
      "সীমাহীন প্রশ্ন — ৫২,০০০+ ভাউল্ট",
      "পূর্ণ ব্যাখ্যা + বই পেজ-রেফারেন্স",
      "সব লাইভ এক্সাম ও দেশসেরা র‍্যাংক",
      "ভুল বুক ও অ্যাডাপ্টিভ রিভিশন",
      "স্মার্ট অ্যানালিটিক্স ও উইকলি রিপোর্ট",
      "অফলাইন ডাউনলোড, সম্পূর্ণ অ্যাড-ফ্রি",
    ],
    featured: true,
  },
  {
    icon: School,
    name: "ইনস্টিটিউশন",
    tagline: "কোচিং ও শিক্ষাপ্রতিষ্ঠানের জন্য",
    monthly: 999,
    yearly: 749,
    yearlyTotal: "৳৮,৯৯৯/বছর",
    cta: "ডেমো বুক করো",
    features: [
      "প্রিমিয়ামের সব সুবিধা",
      "১০০+ ছাত্রের ব্যাচ ম্যানেজমেন্ট",
      "কাস্টম এক্সাম ও প্রশ্ন সেট",
      "ছাত্রভিত্তিক পারফরম্যান্স রিপোর্ট",
      "ডেডিকেটেড সাপোর্ট ম্যানেজার",
    ],
    featured: false,
  },
];

export default function Pricing() {
  const [yearly, setYearly] = useState(true);

  return (
    <section id="pricing" className="relative overflow-hidden py-20 sm:py-28" aria-label="মূল্য তালিকা">
      <div className="absolute left-1/2 top-24 -z-10 size-[36rem] -translate-x-1/2 rounded-full bg-brand-200/40 blur-3xl" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <SectionTag icon={<Wallet className="size-4" />} label="সৎ মূল্য, কোনো লুকানো চার্জ নেই" />
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="font-display mt-5 text-4xl font-bold leading-[1.15] tracking-tight text-ink-950 sm:text-5xl">
              এক কাপ চায়ের দামে <span className="text-gradient">পুরো প্রস্তুতি</span>
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-5 text-lg leading-relaxed text-ink-600">
              ফ্রিতে শুরু করো, দরকার হলেই আপগ্রেড করো। বার্ষিক প্ল্যানে পাও আরও ৩৮% ছাড়।
            </p>
          </Reveal>

          {/* toggle */}
          <Reveal delay={0.25} className="mt-8 inline-flex items-center">
            <div className="glass relative flex items-center rounded-full border border-brand-500/15 p-1.5 shadow-sm">
              {["মাসিক", "বার্ষিক"].map((label, i) => {
                const active = yearly === (i === 1);
                return (
                  <button
                    key={label}
                    onClick={() => setYearly(i === 1)}
                    className="relative rounded-full px-6 py-2.5 text-sm font-bold transition-colors"
                    aria-pressed={active}
                  >
                    {active && (
                      <motion.span
                        layoutId="billing-pill"
                        transition={{ type: "spring", stiffness: 380, damping: 32 }}
                        className="absolute inset-0 rounded-full bg-ink-950 shadow-lg"
                      />
                    )}
                    <span className={`relative z-10 transition-colors duration-300 ${active ? "text-white" : "text-ink-600 hover:text-ink-900"}`}>
                      {label}
                      {i === 1 && (
                        <span className={`ml-1.5 rounded-full px-1.5 py-0.5 text-[10px] font-bold ${active ? "bg-gold-400 text-ink-950" : "bg-emerald-100 text-emerald-700"}`}>
                          −৩৮%
                        </span>
                      )}
                    </span>
                  </button>
                );
              })}
            </div>
          </Reveal>
        </div>

        {/* cards */}
        <Stagger className="mt-14 grid items-stretch gap-6 lg:grid-cols-3" gap={0.14}>
          {PLANS.map((p) => {
            const price = yearly ? p.yearly : p.monthly;
            return (
              <StaggerItem key={p.name} className={p.featured ? "lg:-my-4" : ""}>
                <div
                  className={`relative h-full overflow-hidden rounded-[1.8rem] transition-all duration-500 hover:-translate-y-2 ${
                    p.featured
                      ? "glow-brand border border-brand-400/50 bg-ink-950 text-white shadow-2xl shadow-brand-500/40"
                      : "ring-conic border border-white/70 bg-white/85 backdrop-blur hover:shadow-[0_28px_60px_-30px_rgba(255,82,0,0.4)]"
                  }`}
                >
                  {p.featured && (
                    <>
                      <div className="dot-grid-dark absolute inset-0 opacity-60" />
                      <div className="absolute -right-20 -top-20 size-64 rounded-full bg-brand-600/40 blur-3xl" />
                      <span className="absolute right-5 top-5 z-10 rounded-full bg-gradient-to-r from-gold-400 to-amber-500 px-3.5 py-1.5 text-xs font-bold text-ink-950 shadow-lg shadow-gold-400/40">
                        সবচেয়ে জনপ্রিয়
                      </span>
                    </>
                  )}

                  <div className="relative flex h-full flex-col p-8">
                    <span
                      className={`grid size-12 place-items-center rounded-2xl ${
                        p.featured ? "bg-gradient-to-br from-brand-400 to-amber-500 text-white" : "bg-brand-100 text-brand-700"
                      }`}
                    >
                      <p.icon className="size-5.5" strokeWidth={2.2} />
                    </span>
                    <h3 className={`font-display mt-5 text-2xl font-bold ${p.featured ? "text-white" : "text-ink-950"}`}>{p.name}</h3>
                    <p className={`mt-1 text-sm ${p.featured ? "text-white/55" : "text-ink-500"}`}>{p.tagline}</p>

                    <div className="mt-6 flex items-end gap-2">
                      <AnimatePresence mode="wait">
                        <motion.span
                          key={`${p.name}-${yearly}`}
                          initial={{ opacity: 0, y: 14, filter: "blur(4px)" }}
                          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                          exit={{ opacity: 0, y: -14, filter: "blur(4px)" }}
                          transition={{ duration: 0.4, ease: EASE }}
                          className={`font-display text-5xl font-bold tracking-tight ${p.featured ? "text-white" : "text-ink-950"}`}
                        >
                          ৳{toBn(price.toLocaleString("en-IN"))}
                        </motion.span>
                      </AnimatePresence>
                      <span className={`pb-1.5 text-sm font-semibold ${p.featured ? "text-white/50" : "text-ink-500"}`}>/মাস</span>
                    </div>
                    <p className={`mt-1 h-5 text-xs font-bold ${p.featured ? "text-gold-300" : "text-emerald-600"}`}>
                      {yearly && price > 0 ? `${p.yearlyTotal} — একসাথে` : "\u00A0"}
                    </p>

                    <ul className="mt-6 flex-1 space-y-3.5">
                      {p.features.map((f) => (
                        <li key={f} className="flex items-start gap-2.5">
                          <span
                            className={`mt-0.5 grid size-5 shrink-0 place-items-center rounded-full ${
                              p.featured ? "bg-emerald-400 text-ink-950" : "bg-emerald-100 text-emerald-600"
                            }`}
                          >
                            <Check className="size-3" strokeWidth={3.5} />
                          </span>
                          <span className={`text-[14.5px] leading-snug ${p.featured ? "text-white/80" : "text-ink-700"}`}>{f}</span>
                        </li>
                      ))}
                    </ul>

                    <a
                      href="#cta"
                      className={`btn-shine mt-8 block rounded-full py-3.5 text-center text-base font-bold transition-all duration-300 hover:-translate-y-0.5 ${
                        p.featured
                          ? "bg-gradient-to-r from-brand-500 to-amber-500 text-white shadow-xl shadow-brand-500/40 hover:shadow-2xl hover:shadow-brand-500/60"
                          : "border border-ink-200 bg-ink-950 text-white hover:bg-brand-600 hover:shadow-xl hover:shadow-brand-500/30"
                      }`}
                    >
                      {p.cta}
                    </a>
                  </div>
                </div>
              </StaggerItem>
            );
          })}
        </Stagger>

        <Reveal delay={0.2} className="mt-10">
          <p className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm font-semibold text-ink-500">
            <span className="inline-flex items-center gap-2">
              <ShieldCheck className="size-4.5 text-emerald-500" /> ৭ দিনের মানি-ব্যাক গ্যারান্টি
            </span>
            <span className="hidden size-1 rounded-full bg-ink-300 sm:block" />
            <span>পেমেন্ট: বিকাশ · নগদ · রকেট · ভিসা/মাস্টারকার্ড</span>
            <span className="hidden size-1 rounded-full bg-ink-300 sm:block" />
            <span>যেকোনো সময় বাতিল করা যায়</span>
          </p>
        </Reveal>
      </div>
    </section>
  );
}
