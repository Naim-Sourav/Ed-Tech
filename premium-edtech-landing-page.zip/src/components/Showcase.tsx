import { AnimatePresence, motion } from "framer-motion";
import {
  BadgeCheck,
  BookOpen,
  BrainCircuit,
  Check,
  ChevronLeft,
  ChevronRight,
  Flag,
  Gauge,
  LibraryBig,
  Lock,
  MessageSquareText,
  RotateCcw,
  ThumbsUp,
  X,
} from "lucide-react";
import { useState } from "react";
import { QUESTIONS, TOPPERS } from "../lib/data";
import { EASE, Reveal, Stagger, StaggerItem, toBn } from "../lib/helpers";

const LETTERS = ["ক", "খ", "গ", "ঘ"];

const DIFF_COLOR: Record<string, string> = {
  সহজ: "border-emerald-400/40 bg-emerald-400/10 text-emerald-300",
  মাঝারি: "border-amber-400/40 bg-amber-400/10 text-amber-300",
  কঠিন: "border-rose-400/40 bg-rose-400/10 text-rose-300",
};

const BENEFITS = [
  {
    icon: BookOpen,
    title: "পড়তে যেমন আরাম, তেমন প্রদর্শন",
    text: "নিখুঁত বাংলা টাইপোগ্রাফি ও গণিত-সূত্র রেন্ডারিং — চোখে লেগে থাকে না, মাথায় বসে যায়।",
  },
  {
    icon: LibraryBig,
    title: "প্রতিটি উত্তরে পূর্ণাঙ্গ ব্যাখ্যা",
    text: "গাইড-বইয়ের পেজ-নম্বরসহ রেফারেন্স, ধাপে ধাপে সমাধান আর পরীক্ষার হ্যাক।",
  },
  {
    icon: BrainCircuit,
    title: "ভুল থেকেই আসল শেখা", 
    text: "ভুল প্রশ্ন অটোমেটিক রিভিশনে চলে যায় — একই জায়গায় দ্বিতীয়বার ফাঁদে পড়বে না।",
  },
  {
    icon: Gauge,
    title: "প্রতিটি পদক্ষেপ ট্র্যাকড",
    text: "কারা আগে সলভ করল, তুমি কত দ্রুত — পারসেন্টাইল আর গতি সব দেখো এক নজরে।",
  },
];

function Medal({ rank }: { rank: number }) {
  const cls =
    rank === 1
      ? "from-amber-300 to-orange-500 text-amber-950"
      : rank === 2
        ? "from-slate-200 to-slate-400 text-slate-800"
        : rank === 3
          ? "from-orange-300 to-amber-700 text-orange-950"
          : "from-white/10 to-white/5 text-white/70";
  return (
    <span className={`grid size-8 shrink-0 place-items-center rounded-full bg-gradient-to-br text-sm font-bold shadow ${cls}`}>
      {toBn(rank)}
    </span>
  );
}

export default function Showcase() {
  const [qIndex, setQIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const q = QUESTIONS[qIndex];
  const answered = picked !== null;
  const isCorrect = picked === q.answer;

  const select = (i: number) => {
    if (!answered) setPicked(i);
  };
  const changeQ = (i: number) => {
    setPicked(null);
    setQIndex(i);
  };
  const step = (dir: 1 | -1) => {
    setPicked(null);
    setQIndex((v) => (v + dir + QUESTIONS.length) % QUESTIONS.length);
  };

  return (
    <section id="showcase" className="relative overflow-hidden bg-ink-950 py-20 text-white sm:py-28" aria-label="প্রশ্ন প্রদর্শন">
      {/* ambience */}
      <div className="dot-grid-dark absolute inset-0 opacity-70 [mask-image:radial-gradient(70%_60%_at_50%_40%,black,transparent)]" />
      <div className="absolute -top-40 left-1/4 size-[32rem] rounded-full bg-brand-600/25 blur-3xl" />
      <div className="absolute -bottom-48 right-0 size-[28rem] rounded-full bg-amber-600/20 blur-3xl" />
      <div className="absolute left-0 top-1/2 size-72 rounded-full bg-gold-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid items-center gap-14 lg:grid-cols-[0.9fr_1.1fr] lg:gap-12">
          {/* ---------- left copy ---------- */}
          <div>
            <Reveal>
              <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-sm font-semibold text-brand-200 backdrop-blur">
                <BadgeCheck className="size-4 text-emerald-400" />
                প্রশ্ন প্রদর্শন — আমাদের স্বাক্ষর
              </span>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="font-display mt-6 text-4xl font-bold leading-[1.14] tracking-tight sm:text-5xl">
                প্রশ্ন যেভাবে দেখাতে হয়,
                <br />
                <span className="text-gradient-dark">আমরা তাই জানি</span>
              </h2>
            </Reveal>
            <Reveal delay={0.2}>
              <p className="mt-5 max-w-lg text-lg leading-relaxed text-white/60">
                chorcha বা sattacademy-র মতো প্রিয় সাইটগুলো যেভাবে প্রশ্ন উপস্থাপন করে — তারও এক ধাপ সুন্দর, দ্রুত ও
                প্রাণবন্ত অভিজ্ঞতা। পাশের কার্ডে নিজেই উত্তর দিয়ে ট্রাই করো।
              </p>
            </Reveal>

            <Stagger className="mt-9 space-y-5" gap={0.1}>
              {BENEFITS.map((b) => (
                <StaggerItem key={b.title} className="flex gap-4">
                  <span className="grid size-11 shrink-0 place-items-center rounded-2xl border border-white/10 bg-white/5 text-brand-300">
                    <b.icon className="size-5" strokeWidth={2} />
                  </span>
                  <span>
                    <span className="block text-lg font-bold text-white">{b.title}</span>
                    <span className="mt-1 block leading-relaxed text-white/55">{b.text}</span>
                  </span>
                </StaggerItem>
              ))}
            </Stagger>

            <Reveal delay={0.3} className="mt-9">
              <a
                href="#cta"
                className="group inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-6 py-3 font-bold text-white backdrop-blur transition-all duration-300 hover:border-brand-400 hover:bg-brand-500/20"
              >
                লাইভ অভিজ্ঞতা নাও
                <ChevronRight className="size-5 transition-transform group-hover:translate-x-1" />
              </a>
            </Reveal>
          </div>

          {/* ---------- browser mockup ---------- */}
          <Reveal delay={0.15} y={40}>
            <div className="relative">
              <div className="absolute -inset-5 -z-10 rounded-[2.2rem] bg-gradient-to-br from-brand-500/40 via-amber-500/25 to-gold-400/30 blur-2xl" />

              <div className="overflow-hidden rounded-2xl border border-white/12 bg-[#151322] shadow-2xl shadow-black/60">
                {/* chrome bar */}
                <div className="flex items-center gap-3 border-b border-white/8 bg-[#1b1830] px-4 py-3">
                  <div className="flex gap-1.5">
                    <span className="size-2.5 rounded-full bg-rose-500/90" />
                    <span className="size-2.5 rounded-full bg-amber-400/90" />
                    <span className="size-2.5 rounded-full bg-emerald-500/90" />
                  </div>
                  <div className="flex min-w-0 flex-1 items-center gap-1.5 truncate rounded-lg border border-white/8 bg-black/30 px-3 py-1.5 text-xs text-white/50">
                    <Lock className="size-3 shrink-0 text-emerald-400" />
                    <span className="truncate">porikkhangon.app/q/{q.id}</span>
                  </div>
                  {/* question switcher */}
                  <div className="hidden items-center gap-1.5 sm:flex">
                    {QUESTIONS.map((qq, i) => (
                      <button
                        key={qq.id}
                        onClick={() => changeQ(i)}
                        aria-label={`${qq.subject} প্রশ্ন`}
                        className={`rounded-md px-2 py-1 text-[11px] font-bold transition ${
                          i === qIndex ? "bg-brand-500 text-white" : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white"
                        }`}
                      >
                        {["গণিত", "জীববি.", "ENG", "বাংলা"][i]}
                      </button>
                    ))}
                  </div>
                </div>

                {/* body */}
                <div className="grid md:grid-cols-[1.5fr_0.9fr]">
                  {/* question column */}
                  <div className="min-w-0 border-b border-white/8 p-5 sm:p-6 md:border-b-0 md:border-r">
                    {/* meta */}
                    <div className="flex flex-wrap items-center gap-2 text-[11.5px] font-bold">
                      <span className="rounded-full bg-brand-500/20 px-2.5 py-1 text-brand-200">{q.examTag}</span>
                      <span className="rounded-full bg-white/5 px-2.5 py-1 text-white/60 ring-1 ring-white/10">
                        {q.subject} · {q.chapter}
                      </span>
                      <span className={`rounded-full border px-2.5 py-1 ${DIFF_COLOR[q.difficulty]}`}>{q.difficulty}</span>
                      <span className="ml-auto text-white/40">
                        প্রশ্ন {toBn(qIndex + 1)}/{toBn(QUESTIONS.length)}
                      </span>
                    </div>

                    <AnimatePresence mode="wait">
                      <motion.div
                        key={q.id}
                        initial={{ opacity: 0, y: 18 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -18 }}
                        transition={{ duration: 0.4, ease: EASE }}
                      >
                        <h3 className="font-display mt-4 text-xl font-semibold leading-relaxed text-white sm:text-[1.35rem]">
                          {q.question}
                        </h3>

                        {/* options */}
                        <div className="mt-5 space-y-2.5" role="radiogroup" aria-label="উত্তর নির্বাচন">
                          {q.options.map((opt, i) => {
                            const isPicked = picked === i;
                            const isAns = i === q.answer;
                            let cls = "border-white/10 bg-white/[0.04] hover:border-brand-400/70 hover:bg-brand-500/10";
                            if (answered && isAns)
                              cls = "border-emerald-400/70 bg-emerald-500/15 shadow-[0_0_24px_-6px_rgba(52,211,153,0.5)]";
                            else if (answered && isPicked) cls = "border-rose-400/70 bg-rose-500/12";
                            else if (answered) cls = "border-white/8 bg-white/[0.03] opacity-45";

                            return (
                              <motion.button
                                key={opt}
                                onClick={() => select(i)}
                                disabled={answered}
                                whileTap={!answered ? { scale: 0.985 } : undefined}
                                animate={answered && isPicked && !isAns ? { x: [0, -6, 6, -3, 3, 0] } : {}}
                                transition={{ duration: 0.4 }}
                                role="radio"
                                aria-checked={isPicked}
                                className={`flex w-full items-center gap-3 rounded-xl border px-3.5 py-3 text-left transition-all duration-300 ${cls}`}
                              >
                                <span
                                  className={`grid size-7 shrink-0 place-items-center rounded-lg text-xs font-bold transition ${
                                    answered && isAns
                                      ? "bg-emerald-400 text-emerald-950"
                                      : answered && isPicked && !isAns
                                        ? "bg-rose-400 text-rose-950"
                                        : "bg-white/10 text-white/70"
                                  }`}
                                >
                                  {answered && isAns ? (
                                    <Check className="size-3.5" strokeWidth={3.5} />
                                  ) : answered && isPicked && !isAns ? (
                                    <X className="size-3.5" strokeWidth={3.5} />
                                  ) : (
                                    LETTERS[i]
                                  )}
                                </span>
                                <span className="text-[14.5px] font-medium text-white/85">{opt}</span>
                              </motion.button>
                            );
                          })}
                        </div>

                        {/* explanation */}
                        <AnimatePresence>
                          {answered && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.5, ease: EASE }}
                              className="overflow-hidden"
                            >
                              <div className="mt-4 rounded-xl border border-white/10 bg-gradient-to-br from-brand-500/10 to-transparent p-4">
                                <p className={`flex items-center gap-2 text-sm font-bold ${isCorrect ? "text-emerald-300" : "text-amber-300"}`}>
                                  <BadgeCheck className="size-4" />
                                  {isCorrect ? "পারফেক্ট! +২৫ পয়েন্ট তোমার ব্যাগে" : "মিস করলে ব্যাখ্যাই আসল শিক্ষক"}
                                </p>
                                <ul className="mt-3 space-y-1.5">
                                  {q.explanation.map((line, i) => (
                                    <motion.li
                                      key={i}
                                      initial={{ opacity: 0, x: -10 }}
                                      animate={{ opacity: 1, x: 0 }}
                                      transition={{ delay: 0.15 + i * 0.15, duration: 0.4 }}
                                      className="flex gap-2 text-[13px] leading-relaxed text-white/70"
                                    >
                                      <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brand-400" />
                                      {line}
                                    </motion.li>
                                  ))}
                                </ul>
                                <p className="mt-3 rounded-lg bg-black/25 px-3 py-2 text-[11.5px] font-medium text-white/50">
                                  <span className="font-bold text-gold-300">রেফারেন্স:</span> {q.reference}
                                </p>
                                <div className="mt-3 flex items-center gap-4 text-[11.5px] font-semibold text-white/40">
                                  <span>{q.attempts} টি চেষ্টা</span>
                                  <span>সঠিক {toBn(q.accuracy)}%</span>
                                  <span className="inline-flex items-center gap-1">
                                    <MessageSquareText className="size-3.5" /> {toBn(q.comments)} মন্তব্য
                                  </span>
                                  <span className="ml-auto flex gap-2">
                                    <button className="rounded-md border border-white/10 px-2 py-1 transition hover:bg-white/10" aria-label="রিপোর্ট">
                                      <Flag className="size-3" />
                                    </button>
                                    <button
                                      onClick={() => setPicked(null)}
                                      className="rounded-md border border-white/10 px-2 py-1 transition hover:bg-white/10"
                                      aria-label="আবার চেষ্টা"
                                    >
                                      <RotateCcw className="size-3" />
                                    </button>
                                  </span>
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    </AnimatePresence>

                    {/* footer nav */}
                    <div className="mt-5 flex items-center justify-between border-t border-white/8 pt-4">
                      <button
                        onClick={() => step(-1)}
                        className="inline-flex items-center gap-1 rounded-lg border border-white/10 px-3 py-2 text-xs font-bold text-white/60 transition hover:bg-white/10 hover:text-white"
                      >
                        <ChevronLeft className="size-4" /> আগের
                      </button>
                      <div className="flex gap-1">
                        {QUESTIONS.map((_, i) => (
                          <span
                            key={i}
                            className={`h-1.5 rounded-full transition-all duration-500 ${i === qIndex ? "w-6 bg-brand-400" : "w-1.5 bg-white/15"}`}
                          />
                        ))}
                      </div>
                      <button
                        onClick={() => step(1)}
                        className="inline-flex items-center gap-1 rounded-lg bg-brand-500 px-3.5 py-2 text-xs font-bold text-white shadow-lg shadow-brand-500/30 transition hover:bg-brand-400"
                      >
                        পরের <ChevronRight className="size-4" />
                      </button>
                    </div>
                  </div>

                  {/* right rail */}
                  <aside className="min-w-0 bg-black/20 p-5 sm:p-6">
                    <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white/40">
                      <Gauge className="size-4 text-gold-400" /> এই প্রশ্নে সেরারা
                    </p>
                    <ul className="mt-4 space-y-2.5">
                      {TOPPERS.map((t, i) => (
                        <motion.li
                          key={t.name}
                          initial={{ opacity: 0, x: 16 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: 0.2 + i * 0.1, duration: 0.5 }}
                          className="flex items-center gap-2.5 rounded-xl border border-white/6 bg-white/[0.04] px-2.5 py-2"
                        >
                          <Medal rank={i + 1} />
                          <span className={`grid size-8 shrink-0 place-items-center rounded-full bg-gradient-to-br ${t.grad} text-[11px] font-bold text-white`}>
                            {t.name.slice(0, 1)}
                          </span>
                          <span className="min-w-0">
                            <span className="block truncate text-[13px] font-bold text-white/85">{t.name}</span>
                            <span className="block truncate text-[11px] text-white/40">{t.meta}</span>
                          </span>
                          <span className="ml-auto text-[12px] font-bold text-gold-300">{t.points}</span>
                        </motion.li>
                      ))}
                    </ul>

                    <div className="mt-5 rounded-xl border border-white/8 bg-white/[0.04] p-3.5">
                      <p className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-white/40">
                        <MessageSquareText className="size-3.5 text-amber-300" /> আলোচনা
                      </p>
                      <div className="mt-3 space-y-3">
                        <div className="flex gap-2.5">
                          <span className="grid size-7 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand-500 to-amber-600 text-[10px] font-bold text-white">রা</span>
                          <div>
                            <p className="text-[12px] leading-relaxed text-white/70">
                              গত বছর ঠিক এই প্যাটার্নটা ঢাবি ‘ক’-তে এসেছিল। সূত্রটা মুখস্থ রাখো — দুই লাইনেই সমাধান!
                            </p>
                            <p className="mt-1 flex items-center gap-3 text-[10.5px] font-semibold text-white/35">
                              রাফসান · <span className="inline-flex items-center gap-1"><ThumbsUp className="size-3" /> {toBn(214)}</span>
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2.5">
                          <span className="grid size-7 shrink-0 place-items-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-[10px] font-bold text-white">মে</span>
                          <div>
                            <p className="text-[12px] leading-relaxed text-white/70">
                              ব্যাখ্যায় যে পেজ-রেফারেন্সটা দেয়া — এটার জন্যই আমি এই সাইট ছাড়তে পারিনা।
                            </p>
                            <p className="mt-1 flex items-center gap-3 text-[10.5px] font-semibold text-white/35">
                              মেহজাবিন · <span className="inline-flex items-center gap-1"><ThumbsUp className="size-3" /> {toBn(96)}</span>
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </aside>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
