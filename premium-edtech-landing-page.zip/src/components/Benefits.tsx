import { motion } from "framer-motion";
import { CalendarCheck2, Check, ClipboardList, Compass, TrendingUp, X } from "lucide-react";
import { Reveal, SectionTag, Stagger, StaggerItem, toBn } from "../lib/helpers";

const STEPS = [
  {
    icon: Compass,
    title: "টার্গেট ঠিক করো",
    text: "বিসিএস, ব্যাংক, NTRCA নাকি ঢাবি ‘ক’? এক ট্যাপে পরীক্ষা বাছাই করলেই তোমার জন্য পার্সোনাল সিলেবাস-ম্যাপ তৈরি।",
    grad: "from-brand-500 to-brand-600",
  },
  {
    icon: CalendarCheck2,
    title: "প্রতিদিন স্মার্ট চর্চা",
    text: "অ্যাডাপ্টিভ অ্যালগরিদম তোমার দুর্বল টপিক থেকে প্রশ্ন বেছে দেয় — টাইমড সেট, ডেইলি গোল আর স্ট্রিকে প্রগতির চর্চা চলতে থাকে।",
    grad: "from-amber-500 to-rose-500",
  },
  {
    icon: TrendingUp,
    title: "মক দাও, র‍্যাংক জিতো",
    text: "সাপ্তাহিক লাইভ এক্সামে দেশসেরাদের সাথে নিজেকে মাপো, ভুলগুলো রিভাইজ করো — পরীক্ষার হলে ঢুকবে পূর্ণ আত্মবিশ্বাস নিয়ে।",
    grad: "from-amber-400 to-orange-500",
  },
];

const VS = [
  ["প্রশ্ন নির্ভুলতা", "যাচাই নেই — ভুল উত্তরওই শিখে ফেলা", "সম্পাদকীয় টিমের ৩-স্তর যাচাই", true],
  ["ব্যাখ্যা", "শুধু ‘উত্তর: খ’ — কিছুই মাথায় বসে না", "ধাপে ধাপে সমাধান + বই পেজ-রেফারেন্স", true],
  ["অগ্রগতি", "কোথায় দুর্বল — তা আজন্ম অজানা", "ড্যাশবোর্ডে স্কোর, গতি ও দুর্বলতা", true],
  ["রিভিশন", "আগের ভুল প্রশ্ন আর খুঁজেই পাওয়া যায় না", "অটো ভুল বুক + স্পেসড রিপিটিশন", true],
  ["অ্যাকসেস", "ভারী বই আর ইন্টারনেট-নির্ভর পিডিএফ", "মোবাইলে, অফলাইনে — যেকোনো জায়গায়", true],
  ["অনুপ্রেরণা", "একা পড়া, মাঝপথে হাল ছাড়াটাই স্বাভাবিক", "স্ট্রিক, পয়েন্ট ও লিডারবোর্ডের প্রতিযোগিতা", true],
];

export default function Benefits() {
  return (
    <section className="relative overflow-hidden py-20 sm:py-28" aria-label="সুবিধা">
      <div className="absolute -left-40 top-40 -z-10 size-96 rounded-full bg-brand-200/40 blur-3xl" />
      <div className="absolute -right-40 bottom-24 -z-10 size-96 rounded-full bg-gold-300/25 blur-3xl" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <SectionTag icon={<ClipboardList className="size-4" />} label="মাত্র ৩টি ধাপ" />
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="font-display mt-5 text-4xl font-bold leading-[1.15] tracking-tight text-ink-950 sm:text-5xl">
              পরীক্ষাজয়ের রুটম্যাপ, <span className="text-gradient">মাত্র ৩টা চরণে</span>
            </h2>
          </Reveal>
        </div>

        {/* steps */}
        <Stagger className="relative mt-16 grid gap-6 md:grid-cols-3" gap={0.15}>
          <div className="absolute left-[16%] right-[16%] top-12 hidden border-t-2 border-dashed border-brand-300/60 md:block" aria-hidden />
          {STEPS.map((s, i) => (
            <StaggerItem key={s.title} className="relative">
              <div className="card-shine group relative h-full rounded-[1.6rem] border border-ink-100 bg-white/85 p-7 backdrop-blur transition-all duration-500 hover:-translate-y-2 hover:border-brand-300 hover:shadow-[0_28px_60px_-28px_rgba(255,82,0,0.4)] sm:p-8">
                <div className="flex items-center justify-between">
                  <span
                    className={`grid size-14 place-items-center rounded-2xl bg-gradient-to-br ${s.grad} text-white shadow-xl transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110`}
                  >
                    <s.icon className="size-6" strokeWidth={2.2} />
                  </span>
                  <span className="font-display bg-gradient-to-b from-brand-200 to-transparent bg-clip-text text-6xl font-bold text-transparent">
                    {toBn(i + 1)}
                  </span>
                </div>
                <h3 className="font-display mt-6 text-2xl font-bold text-ink-950">{s.title}</h3>
                <p className="mt-3 leading-relaxed text-ink-600">{s.text}</p>
              </div>
            </StaggerItem>
          ))}
        </Stagger>

        {/* comparison */}
        <Reveal delay={0.1} className="mt-20">
          <div className="ring-conic relative overflow-hidden rounded-[2rem] border border-white/70 bg-white/85 backdrop-blur-xl">
            <div className="grid md:grid-cols-2">
              {/* old way */}
              <div className="relative p-8 sm:p-10">
                <div className="dot-grid absolute inset-0 opacity-50" />
                <div className="relative">
                  <span className="inline-flex items-center gap-2 rounded-full bg-ink-100 px-4 py-1.5 text-sm font-bold text-ink-600">
                    <X className="size-4 text-rose-500" /> পুরনো পদ্ধতি — বই, পিডিএফ, র‍্যান্ডম অ্যাপ
                  </span>
                  <ul className="mt-7 space-y-5">
                    {VS.map((v) => (
                      <li key={v[0] as string} className="flex items-start gap-3">
                        <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-rose-100 text-rose-500">
                          <X className="size-3.5" strokeWidth={3} />
                        </span>
                        <span>
                          <span className="block text-sm font-bold text-ink-800">{v[0]}</span>
                          <span className="mt-0.5 block text-[13.5px] leading-relaxed text-ink-500">{v[1]}</span>
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* porikkhangon */}
              <div className="relative overflow-hidden bg-ink-950 p-8 text-white sm:p-10">
                <div className="absolute -right-24 -top-24 size-80 rounded-full bg-brand-600/30 blur-3xl" />
                <div className="absolute -bottom-28 -left-10 size-72 rounded-full bg-gold-500/15 blur-3xl" />
                <div className="relative">
                  <span className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand-500 to-amber-500 px-4 py-1.5 text-sm font-bold text-white shadow-lg shadow-brand-500/40">
                    <Check className="size-4" strokeWidth={3} /> পরীক্ষাঙ্গনে
                  </span>
                  <ul className="mt-7 space-y-5">
                    {VS.map((v, i) => (
                      <motion.li
                        key={v[0] as string}
                        initial={{ opacity: 0, x: 22 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.15 + i * 0.08, duration: 0.5 }}
                        className="flex items-start gap-3"
                      >
                        <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-emerald-400 text-ink-950">
                          <Check className="size-3.5" strokeWidth={3.5} />
                        </span>
                        <span>
                          <span className="block text-sm font-bold text-white">{v[0]}</span>
                          <span className="mt-0.5 block text-[13.5px] leading-relaxed text-white/60">{v[2]}</span>
                        </span>
                      </motion.li>
                    ))}
                  </ul>
                  <p className="mt-8 inline-flex items-center gap-2 rounded-xl border border-gold-400/30 bg-gold-400/10 px-4 py-2.5 text-sm font-bold text-gold-300">
                    ৯৫% শিক্ষার্থী প্রথম মাসেই স্কোর উন্নত করেছে
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
