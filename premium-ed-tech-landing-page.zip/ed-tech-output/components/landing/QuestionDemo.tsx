import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Check, X, Lightbulb, ChevronRight, Zap, Timer } from "lucide-react";
import { demoQuestions } from "./LandingData";

const EASE = [0.16, 1, 0.3, 1] as const;
const LETTERS = ["ক", "খ", "গ", "ঘ"];

export const QuestionDemo: React.FC = () => {
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [solved, setSolved] = useState(0);
  const [seconds, setSeconds] = useState(1500);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const q = demoQuestions[idx];
  const answered = picked !== null;
  const correct = picked === q.answer;

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setSeconds((s) => (answered ? s : Math.max(0, s - 1)));
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [answered, idx]);

  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");

  const next = () => {
    setSolved((s) => s + 1);
    setIdx((i) => (i + 1) % demoQuestions.length);
    setPicked(null);
    setSeconds(1500);
  };

  return (
    <div className="overflow-hidden rounded-2xl bg-white text-left shadow-[0_30px_70px_-28px_rgba(22,18,16,0.35)] ring-1 ring-black/10">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-black/5 px-5 py-3.5">
        <div className="flex items-center gap-2">
          <span className="rounded-lg bg-[#161210] px-2.5 py-1 font-display text-[11px] font-bold uppercase tracking-wider text-[#ffb92e]">
            লাইভ ট্রাই করো
          </span>
          <span className="text-[12px] font-semibold text-stone-500">{q.tag}</span>
        </div>
        <div className="flex items-center gap-2.5">
          <span className="inline-flex items-center gap-1 rounded-full bg-[#fff1d6] px-2.5 py-0.5 text-[11.5px] font-bold text-[#b45309]">
            <Zap className="h-3 w-3 fill-current text-[#ffb92e]" /> x{solved}
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-black/5 px-2.5 py-0.5 font-display text-[11.5px] font-bold tabular-nums text-stone-600">
            <Timer className="h-3 w-3" /> {mm}:{ss}
          </span>
        </div>
      </div>

      {/* Body */}
      <div className="px-5 py-5">
        <AnimatePresence mode="wait">
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35, ease: EASE }}
          >
            <p className="font-tiro text-[19px] font-bold leading-snug text-[#161210]">
              {idx + 1}. {q.q}
            </p>
            <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {q.options.map((opt, i) => {
                const isAns = i === q.answer;
                const isPick = i === picked;
                const cls = !answered
                  ? "border-black/10 bg-white hover:border-[#ff5200]/50 hover:bg-[#ffede3] hover:shadow-[0_10px_24px_-12px_rgba(255,82,0,0.35)]"
                  : isAns
                    ? "border-[#ff5200] bg-[#ffede3] shadow-[0_10px_26px_-12px_rgba(255,82,0,0.45)]"
                    : isPick
                      ? "border-red-500/60 bg-red-50"
                      : "border-black/10 bg-white opacity-45";
                return (
                  <button
                    key={opt}
                    disabled={answered}
                    onClick={() => setPicked(i)}
                    className={`group flex items-center gap-2.5 rounded-2xl border px-3.5 py-3 text-left transition-all duration-300 ${cls}`}
                  >
                    <span
                      className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg font-tiro text-[13px] font-bold transition-colors ${
                        answered && isAns
                          ? "bg-[#ff5200] text-white"
                          : answered && isPick
                            ? "bg-red-500 text-white"
                            : "bg-black/5 text-stone-500 group-hover:bg-[#ff5200] group-hover:text-white"
                      }`}
                    >
                      {answered && isAns ? (
                        <Check className="h-4 w-4" strokeWidth={3} />
                      ) : answered && isPick ? (
                        <X className="h-4 w-4" strokeWidth={3} />
                      ) : (
                        LETTERS[i]
                      )}
                    </span>
                    <span className="text-[14px] font-semibold text-[#161210]">{opt}</span>
                  </button>
                );
              })}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Footer explanation */}
      <div className="border-t border-black/5 px-5 py-3.5">
        <AnimatePresence mode="wait">
          {answered ? (
            <motion.div
              key="sol"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.35, ease: EASE }}
              className="flex items-center justify-between gap-3 overflow-hidden"
            >
              <div className="flex items-start gap-2.5">
                <span
                  className={`mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full ${
                    correct ? "bg-[#ff5200]" : "bg-red-500"
                  } text-white`}
                >
                  {correct ? (
                    <Check className="h-3.5 w-3.5" strokeWidth={3.5} />
                  ) : (
                    <X className="h-3.5 w-3.5" strokeWidth={3.5} />
                  )}
                </span>
                <div>
                  <p className={`text-[12.5px] font-bold ${correct ? "text-[#e04400]" : "text-red-500"}`}>
                    {correct ? "একদম ঠিক! +৭ পয়েন্ট" : "ভুল হয়েছে — সঠিকটা দেখো"}
                  </p>
                  <p className="mt-0.5 flex items-start gap-1.5 text-[12px] leading-relaxed text-stone-500">
                    <Lightbulb className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#ffb92e]" />
                    {q.why}
                  </p>
                </div>
              </div>
              <button
                onClick={next}
                className="inline-flex shrink-0 items-center gap-1 rounded-full bg-[#161210] px-4 py-2 text-[12.5px] font-bold text-white transition-transform hover:scale-105"
              >
                পরের প্রশ্ন <ChevronRight className="h-4 w-4" />
              </button>
            </motion.div>
          ) : (
            <motion.div
              key="hint"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center justify-between"
            >
              <p className="text-[12px] font-medium text-stone-500">
                যেকোনো উত্তরে ট্যাপ করো —{" "}
                <span className="font-bold text-[#e04400]">সাথে সাথে রেজাল্ট</span>
              </p>
              <div className="flex gap-1.5" aria-hidden="true">
                {demoQuestions.map((_, i) => (
                  <span
                    key={i}
                    className={`h-1.5 rounded-full transition-all duration-500 ${
                      i === idx ? "w-5 bg-[#ff5200]" : "w-1.5 bg-black/15"
                    }`}
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
