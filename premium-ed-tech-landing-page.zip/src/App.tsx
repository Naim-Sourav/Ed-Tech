import { useEffect, useState } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import SocialProof from "./components/SocialProof";
import Features from "./components/Features";
import Showcase from "./components/Showcase";
import Benefits from "./components/Benefits";
import Testimonials from "./components/Testimonials";
import Pricing from "./components/Pricing";
import FAQ from "./components/FAQ";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import AuthPage from "./components/auth/AuthPage";
import Dashboard from "./components/dashboard/Dashboard";

function useHashRoute() {
  const [hash, setHash] = useState(() => window.location.hash);
  useEffect(() => {
    const onChange = () => {
      const h = window.location.hash;
      setHash(h);
      if (h.startsWith("#/")) window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    };
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);
  return hash;
}

function Landing() {
  useEffect(() => {
    const h = window.location.hash;
    if (h && h.length > 1 && !h.startsWith("#/")) {
      const t = setTimeout(() => {
        document.querySelector(h)?.scrollIntoView({ behavior: "smooth" });
      }, 200);
      return () => clearTimeout(t);
    }
  }, []);

  return (
    <div className="min-h-screen bg-paper font-body text-ink antialiased">
      <a
        href="#features"
        className="sr-only z-[60] rounded-full bg-ink px-5 py-2.5 text-sm font-bold text-paper focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to content
      </a>
      <Navbar />
      <main>
        <Hero />
        <SocialProof />
        <Features />
        <Showcase />
        <Benefits />
        <Testimonials />
        <Pricing />
        <FAQ />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}

function AppShell() {
  const hash = useHashRoute();
  const { user, loading } = useAuth();

  const authMode = hash === "#/login" ? "login" : hash === "#/signup" ? "signup" : null;
  const isDashboard = hash.startsWith("#/dashboard");

  /* লগইন হয়ে গেলে root/landing-এ নয়, dashboard-এ */
  useEffect(() => {
    if (loading) return;
    if (user && (!hash || hash === "#/" || !hash.startsWith("#/"))) {
      window.location.hash = "#/dashboard";
      return;
    }
    if (!user && hash.startsWith("#/dashboard")) {
      window.location.hash = "#/login";
    }
  }, [user, loading, hash]);

  if (isDashboard) return <Dashboard />;
  if (authMode) return <AuthPage mode={authMode} />;
  return <Landing />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppShell />
    </AuthProvider>
  );
}
