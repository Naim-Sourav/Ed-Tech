import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import {
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  sendPasswordResetEmail,
  signOut,
  updateProfile,
  type User,
} from "firebase/auth";
import { ref, set, get, serverTimestamp } from "firebase/database";
import { auth, db, googleProvider } from "../lib/firebase";

export interface UserProfile {
  name: string;
  track: string;
  via?: string;
  createdAt?: unknown;
}

interface AuthContextValue {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signUp: (name: string, track: string, email: string, password: string) => Promise<void>;
  logIn: (email: string, password: string) => Promise<void>;
  logInWithGoogle: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

/* ── Firebase error codes → friendly Bangla messages ── */
function banglaError(code: string): string {
  switch (code) {
    case "auth/email-already-in-use":
      return "এই ইমেইল দিয়ে আগেই অ্যাকাউন্ট আছে — লগইন করে দেখো।";
    case "auth/invalid-credential":
    case "auth/wrong-password":
    case "auth/user-not-found":
      return "ইমেইল বা পাসওয়ার্ড ঠিক নেই — আবার চেক করো।";
    case "auth/weak-password":
      return "পাসওয়ার্ড কমপক্ষে ৬ ক্যারেক্টারের হতে হবে।";
    case "auth/invalid-email":
      return "ইমেইল ঠিকানাটা ঠিক নেই।";
    case "auth/too-many-requests":
      return "অনেকবার চেষ্টা হয়ে গেছে — কিছুক্ষণ পরে আবার করো।";
    case "auth/network-request-failed":
      return "ইন্টারনেট সংযোগটা চেক করো।";
    case "auth/popup-closed-by-user":
      return "Google পপ-আপ বন্ধ হয়ে গেছে — আবার চেষ্টা করো।";
    default:
      return "একটু সমস্যা হয়েছে — আবার চেষ্টা করো।";
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        try {
          const snap = await get(ref(db, `users/${u.uid}`));
          if (snap.exists()) setProfile(snap.val() as UserProfile);
          else
            setProfile({
              name: u.displayName || u.email?.split("@")[0] || "শিক্ষার্থী",
              track: "HSC",
            });
        } catch {
          setProfile({ name: u.displayName || "শিক্ষার্থী", track: "HSC" });
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const signUp = async (name: string, track: string, email: string, password: string) => {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(cred.user, { displayName: name });
      try {
        await set(ref(db, `users/${cred.user.uid}`), {
          name,
          track,
          via: "email",
          createdAt: serverTimestamp(),
        });
        setProfile({ name, track, via: "email" });
      } catch {
        /* profile save failing should not block signup */
      }
      setUser({ ...cred.user });
    } catch (err) {
      throw new Error(banglaError((err as { code?: string }).code || ""));
    }
  };

  const logIn = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err) {
      throw new Error(banglaError((err as { code?: string }).code || ""));
    }
  };

  const logInWithGoogle = async () => {
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      try {
        const snap = await get(ref(db, `users/${cred.user.uid}`));
        if (!snap.exists()) {
          await set(ref(db, `users/${cred.user.uid}`), {
            name: cred.user.displayName || "শিক্ষার্থী",
            track: "HSC",
            via: "google",
            createdAt: serverTimestamp(),
          });
        }
      } catch {
        /* non-blocking */
      }
    } catch (err) {
      throw new Error(banglaError((err as { code?: string }).code || ""));
    }
  };

  const resetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (err) {
      throw new Error(banglaError((err as { code?: string }).code || ""));
    }
  };

  const logOut = async () => {
    await signOut(auth);
  };

  return (
    <AuthContext.Provider
      value={{ user, profile, loading, signUp, logIn, logInWithGoogle, resetPassword, logOut }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
