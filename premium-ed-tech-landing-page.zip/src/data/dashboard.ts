/* ── Dashboard mock data (পরে RTDB/API থেকে আসবে) ── */

export const dashStats = [
  { icon: "flame", labelBn: "লাগাতার স্ট্রিক", value: 14, suffix: " দিন", decimals: 0, sub: "সেরা রেকর্ড ২১ দিন", tone: "amber" },
  { icon: "target", labelBn: "সমাধানকৃত প্রশ্ন", value: 4260, suffix: "", decimals: 0, sub: "+১২০ গতকাল", tone: "brand" },
  { icon: "gauge", labelBn: "সামগ্রিক অ্যাকুরেসি", value: 87, suffix: "%", decimals: 0, sub: "+৩% এই সপ্তাহে", tone: "brand" },
  { icon: "trophy", labelBn: "জাতীয় র‍্যাংক", value: 214, suffix: "", decimals: 0, sub: "সাপ্তাহে #৬", tone: "ink" },
];

export const dailyGoal = { target: 50, done: 35 };

export const liveExam = {
  title: "পদার্থবিজ্ঞান লাইভ মক #৪২",
  chapter: "কাজ, ক্ষমতা ও শক্তি",
  questions: 25,
  minutes: 25,
  joined: 3241,
  hourLocal: 21, // আজ রাত ৯টা
};

export const weakTopics = [
  { name: "বল ও নিউটনের সূত্র", subject: "পদার্থবিজ্ঞান", pct: 38, weak: true },
  { name: "জৈব যৌগ", subject: "রসায়ন", pct: 52, weak: true },
  { name: "ম্যাট্রিক্স", subject: "উচ্চতর গণিত", pct: 71, weak: false },
  { name: "কোষ বিভাজন", subject: "জীববিজ্ঞান", pct: 84, weak: false },
];

export const activities = [
  { type: "mock", text: "রসায়ন মডেল টেস্ট #১২ — স্কোর ৮৮%", time: "৩৫ মিনিট আগে" },
  { type: "badge", text: "নতুন ব্যাজ আনলকড: ১৪ দিনের স্ট্রিক", time: "আজ সকালে" },
  { type: "battle", text: "রিফাতকে ১v১ ব্যাটলে হারালে — +১৫ পয়েন্ট", time: "গতকাল" },
  { type: "solve", text: "উচ্চতর গণিতে ১২০ প্রশ্ন সমাধান", time: "গতকাল" },
];

export const badges = [
  { name: "স্ট্রিক মাস্টার", desc: "১৪ দিন লাগাতার", icon: "flame", unlocked: true },
  { name: "ফিজিক্স নিন্জা", desc: "৫০০+ পদার্থ প্রশ্ন", icon: "zap", unlocked: true },
  { name: "ম্যাথ উইজার্ড", desc: "৯০%+ গণিত অ্যাকুরেসি", icon: "sigma", unlocked: true },
  { name: "অ্যার্লি বার্ড", desc: "সকাল ৮টার আগে চর্চা", icon: "sunrise", unlocked: true },
  { name: "পারফেক্ট উইক", desc: "৭ দিন ১০০% টার্গেট", icon: "calendar", unlocked: false },
  { name: "টপ ১০০", desc: "জাতীয় মেধা তালিকা", icon: "trophy", unlocked: false },
];

export const weekChart = [
  { day: "শনি", solved: 25 },
  { day: "রবি", solved: 40 },
  { day: "সোম", solved: 35 },
  { day: "মঙ্গল", solved: 50 },
  { day: "বুধ", solved: 30 },
  { day: "বৃহ", solved: 55 },
  { day: "শুক্র", solved: 35, today: true },
];

export const subjectAccuracy = [
  { name: "পদার্থবিজ্ঞান", pct: 78 },
  { name: "রসায়ন", pct: 65 },
  { name: "উচ্চতর গণিত", pct: 58 },
  { name: "জীববিজ্ঞান", pct: 82 },
  { name: "ICT", pct: 91 },
  { name: "বাংলা ১ম পত্র", pct: 74 },
];

export const upcomingExams = [
  { title: "পদার্থবিজ্ঞান লাইভ মক #৪২", when: "আজ · রাত ৯টা", meta: "২৫ প্রশ্ন · ২৫ মিনিট", live: true, joined: 3241 },
  { title: "উচ্চতর গণিত ১ম পত্র — ফুল সিলেবাস", when: "কাল · সকাল ১০টা", meta: "৫০ প্রশ্ন · ৫০ মিনিট", live: false, joined: 1876 },
  { title: "জীববিজ্ঞান কুইক টেস্ট — কোষ", when: "শুক্রবার · রাত ৮টা", meta: "১৫ প্রশ্ন · ১২ মিনিট", live: false, joined: 940 },
];

export const pastResults = [
  { title: "রসায়ন মডেল টেস্ট #১২", score: 88, rank: 451, date: "আজ" },
  { title: "পদার্থবিজ্ঞান মক #৪১", score: 76, rank: 812, date: "গতকাল" },
  { title: "ICT সাপ্তাহিক টেস্ট", score: 92, rank: 118, date: "২ দিন আগে" },
];

export const leaderboard = [
  { name: "সাদিয়া রহমান", org: "ভিকারুননিসা", pts: 2840 },
  { name: "মেহরাব হক", org: "নটর ডেম", pts: 2815 },
  { name: "তানিয়া আক্তার", org: "ময়মনসিংহ ক্যাডেট", pts: 2790 },
  { name: "আরিফুল ইসলাম", org: "ঢাকা কলেজ", pts: 2765 },
  { name: "ফারহান চৌধুরী", org: "চট্টগ্রাম কলেজ", pts: 2740 },
  { name: "তুমি", org: "তোমার কলেজ", pts: 2715, you: true },
  { name: "নুসরাত জাহান", org: "হলি ক্রস", pts: 2690 },
  { name: "সাকিব রহমান", org: "রাজুক", pts: 2675 },
];
