import { useState } from "react";
import { motion } from "framer-motion";
import {
  Radio,
  Users,
  Crown,
  BrainCircuit,
  TrendingUp,
  Flame,
  LogOut,
  ShieldCheck,
  Sparkle,
  ChevronRight,
  Medal,
} from "lucide-react";
import { upcomingExams, pastResults, weekChart, subjectAccuracy, leaderboard } from "../../data/dashboard";
import { Card, CardHead, FadeIn, TopicBar } from "./widgets";
import { toBn } from "../ui";
import { useAuth } from "../../context/AuthContext";
import QuestionDemo from "../QuestionDemo";

const SUBJECTS = ["সব বিষয়", "পদার্থবিজ্ঞান", "রসায়ন", "উচ্চতর গণিত", "জীববিজ্ঞান", "ICT"];

/* ═══════════ চর্চা ═══════════ */
export function PracticeView() {
  const [subject, setSubject] = useState("সব বিষয়");
  return (
    <div className="space-y-5">
      <FadeIn>
        <h1 className="font-bangla text-[24px] font-extrabold tracking-tight text-ink sm:text-[28px]">
          চর্চা অঙ্গন
        </h1>
        <p className="mt-1 text-[14px] text-mist">বিষয় বেছে নাও — প্রশ্নগুলো তোমার লেভেল অনুযায়ী আসবে।</p>
      </FadeIn>

      <FadeIn delay={0.08} className="flex flex-wrap gap-2">
        {SUBJECTS.map((s) => (
          <button
            key={s}
            onClick={() => setSubject(s)}
            aria-pressed={subject === s}
            className={`focus-ring rounded-full px-4 py-2 text-[13px] font-bold transition-all duration-300 ${
              subject === s
                ? "bg-ink text-paper shadow-[0_10px_22px_-10px_rgba(22,18,16,0.6)]"
                : "bg-white text-mist ring-1 ring-ink/10 hover:text-ink hover:ring-brand/30"
            }`}
          >
            {s}
          </button>
        ))}
      </FadeIn>

      <div className="grid gap-4 xl:grid-cols-[1.55fr_1fr]">
        <FadeIn delay={0.14}>
          <div className="overflow-hidden rounded-[22px] bg-white shadow-[0_8px_24px_-16px_rgba(22,18,16,0.15)] ring-1 ring-ink/8">
            <div className="flex items-center justify-between border-b border-ink/6 bg-paper px-5 py-3">
              <p className="text-[13px] font-bold text-ink">
                লাইভ প্র্যাকটিস সেশন <span className="text-mist">— {subject}</span>
              </p>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-mint px-2.5 py-1 text-[11px] font-bold text-brand-deep">
                <Sparkle className="h-3 w-3" fill="currentColor" /> AI এডাপটিভ
              </span>
            </div>
            <QuestionDemo />
          </div>
        </FadeIn>

        <div className="flex flex-col gap-4">
          <FadeIn delay={0.2}>
            <Card className="p-5">
              <CardHead title="আজকের সেশন" />
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                {[
                  { v: "৩৫", l: "সমাধান" },
                  { v: "৮৯%", l: "অ্যাকুরেসি" },
                  { v: "০৪:১২", l: "ঘড়িতে" },
                ].map((s) => (
                  <div key={s.l} className="rounded-2xl bg-paper px-2 py-3 ring-1 ring-ink/6">
                    <p className="font-bangla text-[19px] font-extrabold text-ink">{s.v}</p>
                    <p className="mt-0.5 text-[10.5px] font-semibold text-mist">{s.l}</p>
                  </div>
                ))}
              </div>
            </Card>
          </FadeIn>
          <FadeIn delay={0.26}>
            <div className="noise relative flex-1 overflow-hidden rounded-[22px] bg-ink p-5 text-white">
              <div
                className="pointer-events-none absolute -right-10 -top-12 h-40 w-40 rounded-full blur-2xl"
                style={{ background: "radial-gradient(closest-side, rgba(255,185,46,0.4), transparent)" }}
                aria-hidden="true"
              />
              <p className="relative flex items-center gap-2 text-[13px] font-bold text-lime">
                <Flame className="h-4 w-4" fill="currentColor" /> স্ট্রিক বাঁচাও!
              </p>
              <p className="relative mt-2 text-[13.5px] leading-relaxed text-white/70">
                আজ আর মাত্র ১৫টা প্রশ্ন করলেই ১৪ দিনের স্ট্রিক ১৫ হবে।
              </p>
              <div className="relative mt-4 h-1.5 overflow-hidden rounded-full bg-white/12">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: "70%" }}
                  transition={{ duration: 1, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
                  className="h-full rounded-full bg-lime"
                />
              </div>
            </div>
          </FadeIn>
        </div>
      </div>
    </div>
  );
}

/* ═══════════ লাইভ এক্সাম ═══════════ */
export function ExamsView() {
  return (
    <div className="space-y-5">
      <FadeIn>
        <h1 className="font-bangla text-[24px] font-extrabold tracking-tight text-ink sm:text-[28px]">লাইভ এক্সাম</h1>
        <p className="mt-1 text-[14px] text-mist">হাজারো শিক্ষার্থীর সাথে একই হলে বসো — সিট বুক করে রাখো।</p>
      </FadeIn>

      <FadeIn delay={0.08} className="grid gap-4 lg:grid-cols-3">
        {upcomingExams.map((e, i) => (
          <motion.div
            key={e.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.12 + i * 0.08, duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          >
            <Card hover className={`flex h-full flex-col p-5 ${e.live ? "ring-2 ring-brand/60" : ""}`}>
              {e.live ? (
                <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-flag px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wider text-white">
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="absolute h-full w-full rounded-full bg-white animate-pulse-ring" />
                    <span className="relative h-1.5 w-1.5 rounded-full bg-white" />
                  </span>
                  লাইভ আজকে
                </span>
              ) : (
                <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-mint px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wider text-brand-deep">
                  আসন্ন
                </span>
              )}
              <h3 className="mt-3 font-bangla text-[16.5px] font-bold leading-snug text-ink">{e.title}</h3>
              <p className="mt-1.5 text-[12.5px] font-semibold text-mist">{e.when} · {e.meta}</p>
              <p className="mt-2.5 flex items-center gap-1.5 text-[12px] font-semibold text-mist">
                <Users className="h-3.5 w-3.5 text-brand" />
                {toBn(e.joined.toLocaleString("en-IN"))} জন রেজিস্টার্ড
              </p>
              <button
                className={`focus-ring mt-auto pt-5 ${
                  e.live
                    ? "inline-flex items-center justify-center gap-2 rounded-full bg-brand py-3 text-[13.5px] font-bold text-white shadow-[0_14px_28px_-14px_rgba(255,82,0,0.7)] transition-all hover:-translate-y-0.5 hover:bg-brand-deep"
                    : "inline-flex items-center justify-center gap-2 rounded-full bg-ink/[0.05] py-3 text-[13.5px] font-bold text-ink ring-1 ring-ink/10 transition-all hover:-translate-y-0.5 hover:ring-brand/30"
                }`}
              >
                {e.live ? (
                  <>
                    <Radio className="h-4 w-4" /> জয়েন করো
                  </>
                ) : (
                  "রিমাইন্ডার সেট করো"
                )}
              </button>
            </Card>
          </motion.div>
        ))}
      </FadeIn>

      <FadeIn delay={0.2}>
        <Card className="p-6">
          <CardHead title="আগের রেজাল্ট" />
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[520px] text-left text-[13.5px]">
              <thead>
                <tr className="border-b border-ink/8 text-[11.5px] font-bold uppercase tracking-wider text-mist">
                  <th className="pb-3 font-bold">এক্সাম</th>
                  <th className="pb-3 font-bold">স্কোর</th>
                  <th className="pb-3 font-bold">জাতীয় মেধা</th>
                  <th className="pb-3 font-bold">তারিখ</th>
                </tr>
              </thead>
              <tbody>
                {pastResults.map((r) => (
                  <tr key={r.title} className="border-b border-ink/5 last:border-0 transition-colors hover:bg-paper">
                    <td className="py-3.5 font-semibold text-ink">{r.title}</td>
                    <td className="py-3.5">
                      <span
                        className={`inline-flex rounded-full px-2.5 py-1 font-display text-[12px] font-bold ${
                          r.score >= 85 ? "bg-mint text-brand-deep" : r.score >= 70 ? "bg-amber-soft text-ink" : "bg-flag/10 text-flag"
                        }`}
                      >
                        {toBn(`${r.score}`)}%
                      </span>
                    </td>
                    <td className="py-3.5 font-display font-bold tabular-nums text-ink/70">#{toBn(`${r.rank}`)}</td>
                    <td className="py-3.5 text-mist">{r.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </FadeIn>
    </div>
  );
}

/* ═══════════ অ্যানালিটিক্স ═══════════ */
export function AnalyticsView() {
  const max = Math.max(...weekChart.map((d) => d.solved));
  return (
    <div className="space-y-5">
      <FadeIn>
        <h1 className="font-bangla text-[24px] font-extrabold tracking-tight text-ink sm:text-[28px]">অ্যানালিটিক্স</h1>
        <p className="mt-1 text-[14px] text-mist">সংখ্যাগুলো মিথ্যা বলে না — এ টা তোমার প্রকৃত ছবি।</p>
      </FadeIn>

      <div className="grid gap-4 xl:grid-cols-[1.35fr_1fr]">
        {/* Weekly chart */}
        <FadeIn delay={0.08}>
          <Card className="p-6">
            <CardHead title="সাপ্তাহিক চর্চা" action={`মোট ${toBn("270")} প্রশ্ন`} />
            <div className="mt-7 flex h-44 items-end justify-between gap-2 sm:gap-3">
              {weekChart.map((d, i) => (
                <div key={d.day} className="group flex flex-1 flex-col items-center gap-2">
                  <span
                    className={`font-display text-[11.5px] font-bold tabular-nums transition-opacity ${
                      d.today ? "text-brand opacity-100" : "text-mist opacity-0 group-hover:opacity-100"
                    }`}
                  >
                    {toBn(`${d.solved}`)}
                  </span>
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${(d.solved / max) * 100}%` }}
                    transition={{ duration: 0.9, delay: 0.2 + i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                    className={`w-full max-w-[44px] rounded-t-xl transition-colors ${
                      d.today ? "bg-gradient-to-t from-brand to-brand-bright shadow-[0_10px_22px_-10px_rgba(255,82,0,0.7)]" : "bg-ink/12 group-hover:bg-brand/30"
                    }`}
                    style={{ minHeight: 6 }}
                  />
                  <span className={`text-[11.5px] font-semibold ${d.today ? "font-bold text-brand" : "text-mist"}`}>{d.day}</span>
                </div>
              ))}
            </div>
          </Card>
        </FadeIn>

        {/* AI insight */}
        <FadeIn delay={0.14}>
          <div className="noise relative flex h-full flex-col overflow-hidden rounded-[22px] bg-ink p-6 text-white">
            <div
              className="pointer-events-none absolute -right-16 -bottom-16 h-56 w-56 rounded-full blur-3xl"
              style={{ background: "radial-gradient(closest-side, rgba(255,82,0,0.5), transparent)" }}
              aria-hidden="true"
            />
            <p className="relative flex items-center gap-2 text-[13px] font-bold uppercase tracking-wider text-lime">
              <BrainCircuit className="h-4 w-4" /> AI ইনসাইট
            </p>
            <ul className="relative mt-5 flex-1 space-y-4">
              {[
                { icon: TrendingUp, text: "বুধ-বৃহস্পতি তোমার পিক ডে — বড় মকগুলো ওই দিনেই রাখো।" },
                { icon: Flame, text: "“জৈব যৌগ”-এ ভুল ৫২% — আজকের রিভিশনে যোগ হয়েছে।" },
                { icon: Medal, text: "আর ১২৫ পয়েন্ট হলেই সাপ্তাহিক টপ ৫ — ধরতে পারবে।" },
              ].map((ins, i) => (
                <motion.li
                  key={ins.text}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.12, duration: 0.5 }}
                  className="flex items-start gap-3"
                >
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/10 text-lime ring-1 ring-white/10">
                    <ins.icon className="h-4 w-4" />
                  </span>
                  <p className="text-[13.5px] leading-relaxed text-white/80">{ins.text}</p>
                </motion.li>
              ))}
            </ul>
          </div>
        </FadeIn>
      </div>

      <FadeIn delay={0.2}>
        <Card className="p-6">
          <CardHead title="বিষয়ভিত্তিক অ্যাকুরেসি" action="চর্চা করো" />
          <div className="mt-5 grid gap-x-10 gap-y-5 sm:grid-cols-2">
            {subjectAccuracy.map((s, i) => (
              <TopicBar key={s.name} name={s.name} subject="" pct={s.pct} weak={s.pct < 70} delay={0.3 + i * 0.08} />
            ))}
          </div>
        </Card>
      </FadeIn>
    </div>
  );
}

/* ═══════════ লিডারবোর্ড ═══════════ */
export function LeaderboardView() {
  const top3 = leaderboard.slice(0, 3);
  const rest = leaderboard.slice(3);
  const medals = ["bg-gold text-ink", "bg-amber-soft text-ink", "bg-mint text-brand-deep"];
  return (
    <div className="space-y-5">
      <FadeIn>
        <h1 className="font-bangla text-[24px] font-extrabold tracking-tight text-ink sm:text-[28px]">
          সাপ্তাহিক লিডারবোর্ড
        </h1>
        <p className="mt-1 text-[14px] text-mist">রোববার রাত ১২টায় রিসেট — হিসাব এখনো চলছে।</p>
      </FadeIn>

      {/* Top 3 */}
      <FadeIn delay={0.08} className="grid grid-cols-3 gap-3 sm:gap-4">
        {top3.map((p, i) => (
          <motion.div
            key={p.name}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.14 + i * 0.1, duration: 0.55, ease: [0.34, 1.56, 0.64, 1] }}
          >
            <Card className={`relative flex flex-col items-center p-4 pt-5 text-center sm:p-5 ${i === 0 ? "ring-2 ring-gold/70" : ""}`}>
              {i === 0 && <Crown className="absolute -top-3.5 h-6 w-6 text-gold" fill="currentColor" />}
              <span className={`grid h-10 w-10 place-items-center rounded-full font-display text-[14px] font-bold sm:h-12 sm:w-12 ${medals[i]}`}>
                {p.name.charAt(0)}
              </span>
              <p className="mt-2.5 line-clamp-1 text-[12.5px] font-bold text-ink sm:text-[14px]">{p.name}</p>
              <p className="line-clamp-1 text-[10.5px] font-medium text-mist sm:text-[11.5px]">{p.org}</p>
              <p className="mt-2 font-display text-[15px] font-bold tabular-nums text-brand-deep sm:text-[17px]">
                {toBn(p.pts.toLocaleString("en-IN"))}
              </p>
            </Card>
          </motion.div>
        ))}
      </FadeIn>

      {/* Rest */}
      <FadeIn delay={0.2}>
        <Card className="p-3 sm:p-4">
          <ul>
            {rest.map((p, i) => (
              <li
                key={p.name}
                className={`flex items-center gap-3 rounded-2xl px-3.5 py-3 sm:px-4 ${
                  p.you ? "bg-mint ring-1 ring-brand/25" : "transition-colors hover:bg-paper"
                }`}
              >
                <span className="w-6 text-center font-display text-[13px] font-bold tabular-nums text-mist">
                  {toBn(`${i + 4}`)}
                </span>
                <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full text-[12px] font-bold ${
                  p.you ? "ring-conic text-white" : "bg-ink/[0.06] text-ink/60"
                }`}>
                  {p.name.charAt(0)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className={`truncate text-[13.5px] font-bold ${p.you ? "text-brand-deep" : "text-ink"}`}>{p.name}</p>
                  <p className="truncate text-[11px] font-medium text-mist">{p.org}</p>
                </div>
                {p.you && (
                  <span className="hidden shrink-0 rounded-full bg-brand px-2.5 py-1 text-[10.5px] font-bold text-white sm:block">
                    তুমি
                  </span>
                )}
                <span className="shrink-0 font-display text-[13.5px] font-bold tabular-nums text-ink/70">
                  {toBn(p.pts.toLocaleString("en-IN"))}
                </span>
                <ChevronRight className="h-4 w-4 shrink-0 text-ink/20" />
              </li>
            ))}
          </ul>
        </Card>
      </FadeIn>
    </div>
  );
}

/* ═══════════ প্রোফাইল ═══════════ */
export function ProfileView() {
  const { user, profile, logOut } = useAuth();
  const name = profile?.name || user?.displayName || "শিক্ষার্থী";

  return (
    <div className="max-w-2xl space-y-5">
      <FadeIn>
        <h1 className="font-bangla text-[24px] font-extrabold tracking-tight text-ink sm:text-[28px]">প্রোফাইল</h1>
      </FadeIn>

      <FadeIn delay={0.08}>
        <Card className="flex flex-col items-center gap-4 p-6 text-center sm:flex-row sm:text-left">
          <span className="ring-conic grid h-20 w-20 shrink-0 place-items-center rounded-[26%] font-bangla text-[30px] font-extrabold text-white shadow-[0_16px_36px_-14px_rgba(255,82,0,0.6)]">
            {name.trim().charAt(0)}
          </span>
          <div className="min-w-0">
            <h2 className="font-bangla text-[20px] font-extrabold text-ink">{name}</h2>
            <p className="mt-0.5 truncate text-[13px] font-medium text-mist">{user?.email}</p>
            <div className="mt-2.5 flex flex-wrap justify-center gap-2 sm:justify-start">
              <span className="rounded-full bg-mint px-3 py-1 text-[11.5px] font-bold text-brand-deep">
                ট্র্যাক: {profile?.track || "HSC"}
              </span>
              <span className="rounded-full bg-ink/[0.05] px-3 py-1 text-[11.5px] font-bold text-ink/60 ring-1 ring-ink/8">
                ফ্রি প্ল্যান
              </span>
            </div>
          </div>
        </Card>
      </FadeIn>

      <FadeIn delay={0.14}>
        <div className="noise relative overflow-hidden rounded-[22px] bg-ink p-6 text-white">
          <div
            className="pointer-events-none absolute -right-14 -top-14 h-48 w-48 rounded-full blur-3xl"
            style={{ background: "radial-gradient(closest-side, rgba(255,185,46,0.4), transparent)" }}
            aria-hidden="true"
          />
          <p className="relative flex items-center gap-2 text-[13px] font-bold text-lime">
            <ShieldCheck className="h-4 w-4" /> প্রো-তে আপগ্রেড করো
          </p>
          <p className="relative mt-2 max-w-sm text-[13.5px] leading-relaxed text-white/70">
            আনলিমিটেড মক, AI দুর্বলতা রিপোর্ট আর অফলাইন প্যাক — মাসে মাত্র {toBn("299")} টাকায়।
          </p>
          <a
            href="#pricing"
            className="focus-ring relative mt-4 inline-flex items-center gap-2 rounded-full bg-lime px-5 py-2.5 text-[13.5px] font-extrabold text-ink transition-all hover:-translate-y-0.5"
          >
            প্ল্যানগুলো দেখো
          </a>
        </div>
      </FadeIn>

      <FadeIn delay={0.2}>
        <Card className="p-2">
          <button
            onClick={async () => {
              await logOut();
              window.location.hash = "#/";
            }}
            className="focus-ring flex w-full items-center justify-center gap-2.5 rounded-[18px] py-3.5 text-[14.5px] font-bold text-flag transition-colors hover:bg-flag/8"
          >
            <LogOut className="h-[18px] w-[18px]" /> লগ আউট
          </button>
        </Card>
      </FadeIn>
    </div>
  );
}
