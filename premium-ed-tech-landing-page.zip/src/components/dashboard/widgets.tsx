import React from "react";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Counter, toBn } from "../ui";

/* ── Card shell ── */
export function Card({
  children,
  className = "",
  hover = false,
}: {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
}) {
  return (
    <div
      className={`rounded-[22px] bg-white ring-1 ring-ink/8 transition-shadow duration-500 ${
        hover ? "hover:shadow-[0_24px_48px_-24px_rgba(22,18,16,0.25)]" : "shadow-[0_8px_24px_-16px_rgba(22,18,16,0.15)]"
      } ${className}`}
    >
      {children}
    </div>
  );
}

/* ── Card header ── */
export function CardHead({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex items-center justify-between">
      <h3 className="font-bangla text-[16.5px] font-bold text-ink">{title}</h3>
      {action && (
        <button
          onClick={onAction}
          className="focus-ring group inline-flex items-center gap-1 text-[12.5px] font-bold text-brand-deep transition-colors hover:text-brand"
        >
          {action}
          <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5" />
        </button>
      )}
    </div>
  );
}

/* ── Dashboard fade-in wrapper ── */
export function FadeIn({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18, filter: "blur(4px)" }}
      animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      transition={{ duration: 0.6, delay, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ── Stat card ── */
const toneStyles: Record<string, { chip: string; ring: string }> = {
  brand: { chip: "bg-mint text-brand-deep", ring: "ring-brand/15" },
  amber: { chip: "bg-amber-soft text-gold", ring: "ring-gold/20" },
  ink: { chip: "bg-ink text-lime", ring: "ring-ink/10" },
};

export function StatCard({
  icon,
  label,
  value,
  suffix,
  sub,
  tone = "brand",
  delay = 0,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  suffix: string;
  sub: string;
  tone?: "brand" | "amber" | "ink";
  delay?: number;
}) {
  const t = toneStyles[tone];
  return (
    <FadeIn delay={delay}>
      <Card hover className="group p-5">
        <div className="flex items-center justify-between">
          <span className={`grid h-10 w-10 place-items-center rounded-xl ring-1 ${t.chip} ${t.ring} transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110`}>
            {icon}
          </span>
          <span className="text-[11px] font-bold text-mist">{sub}</span>
        </div>
        <p className="mt-4 font-bangla text-[30px] font-extrabold leading-none tracking-tight text-ink">
          <Counter value={value} suffix={suffix} bn />
        </p>
        <p className="mt-1.5 text-[13px] font-semibold text-mist">{label}</p>
      </Card>
    </FadeIn>
  );
}

/* ── Progress ring ── */
export function ProgressRing({
  pct,
  size = 96,
  stroke = 9,
}: {
  pct: number;
  size?: number;
  stroke?: number;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg viewBox={`0 0 ${size} ${size}`} className="h-full w-full -rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(22,18,16,0.07)" strokeWidth={stroke} />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="url(#ringGrad)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c * (1 - pct / 100) }}
          transition={{ duration: 1.4, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
        />
        <defs>
          <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ff5200" />
            <stop offset="100%" stopColor="#ffb92e" />
          </linearGradient>
        </defs>
      </svg>
      <span className="absolute inset-0 grid place-items-center font-bangla text-[19px] font-extrabold text-ink">
        {toBn(`${pct}`)}%
      </span>
    </div>
  );
}

/* ── Weak topic bar ── */
export function TopicBar({ name, subject, pct, weak, delay = 0 }: { name: string; subject: string; pct: number; weak?: boolean; delay?: number }) {
  return (
    <div>
      <div className="flex items-center justify-between gap-3 text-[13px]">
        <p className={`font-bold ${weak ? "text-ink" : "text-ink/70"}`}>
          {name}
          <span className="ml-2 text-[11px] font-semibold text-mist">{subject}</span>
        </p>
        <span className={`font-display text-[12.5px] font-bold tabular-nums ${weak ? "text-flag" : "text-mist"}`}>
          {toBn(`${pct}`)}%
        </span>
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-ink/[0.06]">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 1, delay, ease: [0.16, 1, 0.3, 1] }}
          className={`h-full rounded-full ${weak ? "bg-gradient-to-r from-flag to-brand" : "bg-brand"}`}
        />
      </div>
    </div>
  );
}
