import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Flame,
  Target,
  Gauge,
  Trophy,
  Radio,
  Users,
  Zap,
  Medal,
  Swords,
  BookOpenCheck,
  ArrowRight,
  Bell,
  Sigma,
  CalendarCheck,
  Sunrise,
  Clock3,
} from "lucide-react";
import {
  dashStats,
  dailyGoal,
  liveExam,
  weakTopics,
  activities,
  badges,
} from "../../data/dashboard";
import { Card, CardHead, FadeIn, StatCard, ProgressRing, TopicBar } from "./widgets";
import { toBn } from "../ui";

const statIcons: Record<string, React.ReactNode> = {
  flame: <Flame className="h-5 w-5" fill="currentColor" />,
  target: <Target className="h-5 w-5" />,
  gauge: <Gauge className="h-5 w-5" />,
  trophy: <Trophy className="h-5 w-5" />,
};

const badgeIcons: Record<string, React.ReactNode> = {
  flame: <Flame className="h-5 w-5" />,
  zap: <Zap className="h-5 w-5" />,
  sigma: <Sigma className="h-5 w-5" />,
  sunrise: <Sunrise className="h-5 w-5" />,
  calendar: <CalendarCheck className="h-5 w-5" />,
  trophy: <Trophy className="h-5 w-5" />,
};

const actIcons: Record<string, { icon: React.ReactNode; bg: string }> = {
  mock: { icon: <Target className="h-4 w-4" />, bg: "bg-mint text-brand-deep" },
  badge: { icon: <Medal className="h-4 w-4" />, bg: "bg-amber-soft text-gold" },
  battle: { icon: <Swords className="h-4 w-4" />, bg: "bg-flag/10 text-flag" },
  solve: { icon: <BookOpenCheck className="h-4 w-4" />, bg: "bg-ink/[0.06] text-ink" },
};

function greeting() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return "শুভ সকাল";
  if (h >= 12 && h < 16) return "শুভ দুপুর";
  if (h >= 16 && h < 19) return "শুভ বিকেল";
  return "শুভ রাত";
}

/* ── লাইভ এক্সাম কাউন্টডাউন ── */
function useCountdown() {
  const target = useMemo(() => {
    const d = new Date();
    d.setHours(liveExam.hourLocal, 0, 0, 0);
    if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
    return d.getTime();
  }, []);
  const [left, setLeft] = useState(target - Date.now());
  useEffect(() => {
    const t = setInterval(() => setLeft(Math.max(0, target - Date.now())), 1000);
    return () => clearInterval(t);
  }, [target]);
  const h = Math.floor(left / 3600000);
  const m = Math.floor((left % 3600000) / 60000);
  const s = Math.floor((left % 60000) / 1000);
  return { h, m, s };
}

export default function Overview({ name, goTab }: { name: string; goTab: (t: string) => void }) {
  const { h, m, s } = useCountdown();
  const dateStr = new Date().toLocaleDateString("bn-BD", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
  const pct = Math.round((dailyGoal.done / dailyGoal.target) * 100);

  return (
    <div className="space-y-5">
      {/* ── গ্রিটিং ── */}
      <FadeIn className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[13px] font-semibold text-mist">{dateStr}</p>
          <h1 className="mt-1 font-bangla text-[26px] font-extrabold tracking-tight text-ink sm:text-[32px]">
            {greeting()}, <span className="text-brand">{name.split(" ")[0]}</span>
          </h1>
          <p className="mt-1 text-[14px] text-mist">আজকের চর্চা শুরুর আগে অঙ্গনটা উত্তপ্ত করে নাও।</p>
        </div>
        <button className="focus-ring relative grid h-11 w-11 place-items-center rounded-full bg-white ring-1 ring-ink/10 transition-all hover:ring-brand/30" aria-label="Notifications">
          <Bell className="h-5 w-5 text-ink/70" />
          <span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-brand ring-2 ring-white" />
        </button>
      </FadeIn>

      {/* ── স্ট্যাট ── */}
      <div className="grid grid-cols-2 gap-3.5 xl:grid-cols-4">
        {dashStats.map((stat, i) => (
          <StatCard
            key={stat.labelBn}
            icon={statIcons[stat.icon]}
            label={stat.labelBn}
            value={stat.value}
            suffix={stat.suffix}
            sub={stat.sub}
            tone={stat.tone as "brand" | "amber" | "ink"}
            delay={0.08 + i * 0.07}
          />
        ))}
      </div>

      {/* ── গোল + লাইভ এক্সাম ── */}
      <div className="grid gap-4 lg:grid-cols-[1fr_1.35fr]">
        <FadeIn delay={0.2}>
          <Card className="flex h-full items-center gap-6 p-6">
            <ProgressRing pct={pct} />
            <div className="min-w-0 flex-1">
              <p className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist">আজকের টার্গেট</p>
              <p className="mt-1.5 font-bangla text-[22px] font-extrabold leading-tight text-ink">
                {toBn(`${dailyGoal.done}`)}/{toBn(`${dailyGoal.target}`)} প্রশ্ন
              </p>
              <p className="mt-1 text-[12.5px] font-medium text-mist">আর মাত্র {toBn(`${dailyGoal.target - dailyGoal.done}`)}টা — পারবেই!</p>
              <button
                onClick={() => goTab("practice")}
                className="focus-ring group mt-4 inline-flex items-center gap-2 rounded-full bg-brand px-5 py-2.5 text-[13.5px] font-bold text-white shadow-[0_12px_26px_-12px_rgba(255,82,0,0.7)] transition-all hover:-translate-y-0.5 hover:bg-brand-deep"
              >
                চর্চা চালিয়ে যাও
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </button>
            </div>
          </Card>
        </FadeIn>

        {/* লাইভ এক্সাম — dark card */}
        <FadeIn delay={0.26}>
          <div className="noise relative h-full overflow-hidden rounded-[22px] bg-ink p-6 text-white shadow-[0_28px_56px_-28px_rgba(22,18,16,0.6)]">
            <div
              className="pointer-events-none absolute -right-16 -top-20 h-64 w-64 rounded-full blur-3xl"
              style={{ background: "radial-gradient(closest-side, rgba(255,82,0,0.5), transparent)" }}
              aria-hidden="true"
            />
            <div className="relative flex h-full flex-col justify-between gap-5 sm:flex-row sm:items-center">
              <div>
                <p className="inline-flex items-center gap-2 rounded-full bg-flag/90 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white">
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="absolute h-full w-full rounded-full bg-white animate-pulse-ring" />
                    <span className="relative h-1.5 w-1.5 rounded-full bg-white" />
                  </span>
                  আজ রাত ৯টা · লাইভ
                </p>
                <h3 className="mt-3 font-bangla text-[21px] font-extrabold leading-snug">{liveExam.title}</h3>
                <p className="mt-1 text-[13.5px] text-white/60">
                  {liveExam.chapter} · {toBn(`${liveExam.questions}`)} প্রশ্ন · {toBn(`${liveExam.minutes}`)} মিনিট
                </p>
                <p className="mt-3 flex items-center gap-1.5 text-[12.5px] font-semibold text-white/70">
                  <Users className="h-4 w-4 text-lime" />
                  <span className="font-display tabular-nums text-lime">{toBn(liveExam.joined.toLocaleString("en-IN"))}</span> জন অপেক্ষা করছে
                </p>
              </div>
              <div className="shrink-0">
                <p className="flex items-center gap-1.5 text-[11.5px] font-bold uppercase tracking-wider text-white/50">
                  <Clock3 className="h-3.5 w-3.5" /> শুরু হতে বাকি
                </p>
                <div className="mt-2 flex gap-2">
                  {[
                    { v: h, l: "ঘণ্টা" },
                    { v: m, l: "মিনিট" },
                    { v: s, l: "সেকেন্ড" },
                  ].map((u) => (
                    <span key={u.l} className="w-[62px] rounded-2xl bg-white/8 px-2 py-2.5 text-center ring-1 ring-white/12">
                      <span className="block font-bangla text-[22px] font-extrabold tabular-nums leading-none">
                        {toBn(String(u.v).padStart(2, "0"))}
                      </span>
                      <span className="mt-1 block text-[10.5px] font-semibold text-white/50">{u.l}</span>
                    </span>
                  ))}
                </div>
                <button
                  onClick={() => goTab("exams")}
                  className="focus-ring mt-3 inline-flex w-full items-center justify-center gap-2 rounded-full bg-lime px-5 py-3 text-[13.5px] font-extrabold text-ink transition-all hover:-translate-y-0.5 hover:shadow-[0_14px_30px_-10px_rgba(255,185,46,0.6)]"
                >
                  <Radio className="h-4 w-4" /> সিট বুক করো
                </button>
              </div>
            </div>
          </div>
        </FadeIn>
      </div>

      {/* ── দুর্বলতা + অ্যাক্টিভিটি ── */}
      <div className="grid gap-4 lg:grid-cols-2">
        <FadeIn delay={0.3}>
          <Card className="p-6">
            <CardHead title="AI ফোকাস জোন" action="অ্যানালিটিক্স" onAction={() => goTab("analytics")} />
            <p className="mt-1 text-[12.5px] text-mist">যেগুলো ঠিক করলেই স্কোর ল্যাফ দেবে</p>
            <div className="mt-5 space-y-5">
              {weakTopics.map((t, i) => (
                <TopicBar key={t.name} name={t.name} subject={t.subject} pct={t.pct} weak={t.weak} delay={0.4 + i * 0.12} />
              ))}
            </div>
          </Card>
        </FadeIn>

        <FadeIn delay={0.34}>
          <Card className="p-6">
            <CardHead title="সাম্প্রতিক অ্যাক্টিভিটি" action="সব দেখো" />
            <ul className="mt-4 space-y-1">
              {activities.map((a, i) => (
                <motion.li
                  key={a.text}
                  initial={{ opacity: 0, x: -14 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.42 + i * 0.09, duration: 0.5 }}
                  className="flex items-center gap-3.5 rounded-2xl px-2 py-2.5 transition-colors hover:bg-paper"
                >
                  <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${actIcons[a.type].bg}`}>
                    {actIcons[a.type].icon}
                  </span>
                  <p className="min-w-0 flex-1 truncate text-[13.5px] font-semibold text-ink/80">{a.text}</p>
                  <span className="shrink-0 text-[11.5px] font-semibold text-mist">{a.time}</span>
                </motion.li>
              ))}
            </ul>
          </Card>
        </FadeIn>
      </div>

      {/* ── ব্যাজ ── */}
      <FadeIn delay={0.4}>
        <Card className="p-6">
          <CardHead title="তোমার ব্যাজ কালেকশন" action={`${toBn("4")}/${toBn("6")} আনলকড`} />
          <div className="mt-5 grid grid-cols-3 gap-3 sm:grid-cols-6">
            {badges.map((b, i) => (
              <motion.div
                key={b.name}
                initial={{ opacity: 0, y: 16, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: 0.48 + i * 0.07, duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
                className={`group flex flex-col items-center rounded-2xl px-2 py-4 text-center ring-1 transition-all duration-300 hover:-translate-y-1 ${
                  b.unlocked
                    ? "bg-mint/60 ring-brand/15 hover:shadow-[0_14px_28px_-14px_rgba(255,82,0,0.4)]"
                    : "bg-paper ring-ink/8 opacity-55 grayscale"
                }`}
              >
                <span
                  className={`grid h-11 w-11 place-items-center rounded-2xl ${
                    b.unlocked ? "ring-conic text-white shadow-[0_8px_18px_-6px_rgba(255,82,0,0.55)]" : "bg-ink/10 text-ink/40"
                  }`}
                >
                  {badgeIcons[b.icon]}
                </span>
                <p className="mt-2.5 text-[11.5px] font-bold leading-tight text-ink">{b.name}</p>
                <p className="mt-0.5 text-[10px] font-medium leading-tight text-mist">{b.desc}</p>
              </motion.div>
            ))}
          </div>
        </Card>
      </FadeIn>
    </div>
  );
}
