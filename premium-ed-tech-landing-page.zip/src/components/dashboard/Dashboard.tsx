import { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home, BookOpen, PenLine, History, UserRound,
  Flame, Trophy, Target, ClipboardList, Swords,
  Bookmark, AlertCircle, ChevronRight, Star, Crown,
  Zap, Play, Radio, BrainCircuit, WifiOff, ArrowRight,
  Settings, LogOut, Check,
} from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { LogoMark, toBn } from "../ui";
import { ref, get, onValue } from "firebase/database";
import { db } from "../../lib/firebase";

/* ─── Types ─── */
interface UserStats {
  points: number;
  totalExams: number;
  accuracy: number;
  streak: number;
  rank: number;
  weeklyStreak: boolean[]; // 7 days
}

interface LeaderEntry {
  uid: string;
  name: string;
  org: string;
  points: number;
  photoURL?: string;
}

/* ─── Helpers ─── */
const EASE = [0.16, 1, 0.3, 1] as const;
const RANK_MEDAL = ["bg-[#FFD700] text-[#7a5800]", "bg-[#E8E8E8] text-[#4a4a4a]", "bg-[#CD7F32] text-white"];

function greeting() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return "☀️ শুভ সকাল";
  if (h >= 12 && h < 16) return "🌤️ শুভ দুপুর";
  if (h >= 16 && h < 19) return "🌥️ শুভ বিকেল";
  return "🌙 শুভ রাত";
}

/* ─── Splash ─── */
function Splash() {
  return (
    <div className="grid min-h-screen place-items-center bg-[#faf9f6]">
      <div className="flex flex-col items-center gap-4">
        <motion.div
          animate={{ scale: [1, 1.08, 1], rotate: [0, 5, -5, 0] }}
          transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
        >
          <LogoMark size={64} />
        </motion.div>
        <p className="font-bangla text-[14px] font-semibold text-stone-500">তোমার অঙ্গন তৈরি হচ্ছে…</p>
      </div>
    </div>
  );
}

/* ─── Quick-access items ─── */
const QUICK = [
  { label: "প্রশ্ন ব্যাংক", icon: BookOpen, bg: "bg-[#FFF0E6]", iconColor: "text-[#FF5200]", tab: "qbank" },
  { label: "ফ্ল্যাশ কার্ড", icon: Zap, bg: "bg-[#FFF8E1]", iconColor: "text-[#FFB300]", tab: "flash" },
  { label: "মডেল টেস্ট", icon: ClipboardList, bg: "bg-[#E8F5E9]", iconColor: "text-[#388E3C]", tab: "exams" },
  { label: "ব্যাটল", icon: Swords, bg: "bg-[#FCE4EC]", iconColor: "text-[#E91E63]", tab: "battle" },
  { label: "সেভড", icon: Bookmark, bg: "bg-[#FFF9C4]", iconColor: "text-[#F9A825]", tab: "saved" },
  { label: "ভুল প্রশ্ন", icon: AlertCircle, bg: "bg-[#E8EAF6]", iconColor: "text-[#5C6BC0]", tab: "wrong" },
];

const NAV_TABS = [
  { id: "home", label: "হোম", icon: Home },
  { id: "exams", label: "এক্সাম", icon: ClipboardList },
  { id: "practice", label: "চর্চা", icon: PenLine },
  { id: "history", label: "ইতিহাস", icon: History },
  { id: "profile", label: "প্রোফাইল", icon: UserRound },
];

/* ═══════════════════════════════════════════════
   HOME TAB
═══════════════════════════════════════════════ */
function HomeTab({
  name, stats, leaders, goTab,
}: {
  name: string;
  stats: UserStats;
  leaders: LeaderEntry[];
  goTab: (t: string) => void;
}) {
  return (
    <div className="space-y-4 pb-32">
      {/* ── Orange hero banner ── */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: EASE }}
        className="relative overflow-hidden rounded-[24px] bg-gradient-to-br from-[#FF5200] via-[#FF6B1A] to-[#FF8C42] p-5 text-white shadow-[0_16px_40px_-12px_rgba(255,82,0,0.6)]"
      >
        {/* decorative circles */}
        <div className="pointer-events-none absolute -right-8 -top-8 h-40 w-40 rounded-full bg-white/10" aria-hidden="true" />
        <div className="pointer-events-none absolute -bottom-10 right-12 h-28 w-28 rounded-full bg-white/8" aria-hidden="true" />

        <div className="flex items-start justify-between">
          <div>
            <p className="text-[13px] font-semibold text-white/80">{greeting()}</p>
            <h2 className="mt-1 font-bangla text-[30px] font-extrabold leading-none tracking-tight">
              {name.split(" ")[0]}
            </h2>
            <p className="mt-1.5 text-[13px] text-white/75">আজকের প্রস্তুতি শুরু হোক একটি পরীক্ষা দিয়ে!</p>
          </div>
          <div className="flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-2xl bg-white/20 backdrop-blur-sm ring-1 ring-white/30">
            <Trophy className="h-6 w-6 text-white/90" />
            <p className="mt-0.5 font-bangla text-[13px] font-extrabold leading-none">#{toBn(`${stats.rank}`)}</p>
            <p className="text-[9px] font-semibold text-white/70">র‍্যাংক</p>
          </div>
        </div>

        {/* mini stats strip */}
        <div className="mt-5 flex gap-2.5">
          {[
            { icon: Star, val: toBn(`${stats.points.toLocaleString("en-IN")}`), label: "পয়েন্ট" },
            { icon: ClipboardList, val: toBn(`${stats.totalExams}`), label: "পরীক্ষা" },
            { icon: Target, val: `${toBn(`${stats.accuracy}`)}%`, label: "নির্ভুলতা" },
          ].map((s) => (
            <div key={s.label} className="flex flex-1 items-center gap-2 rounded-2xl bg-white/15 px-3 py-2.5 backdrop-blur-sm">
              <s.icon className="h-4 w-4 shrink-0 text-white/80" />
              <div className="min-w-0">
                <p className="font-bangla text-[17px] font-extrabold leading-none">{s.val}</p>
                <p className="text-[10px] font-semibold text-white/70">{s.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <button
          onClick={() => goTab("exams")}
          className="mt-4 flex items-center gap-2 rounded-full bg-white px-5 py-2.5 text-[14px] font-extrabold text-[#FF5200] shadow-sm transition-transform active:scale-95"
        >
          <Play className="h-4 w-4" fill="currentColor" />
          মডেল টেস্ট দিন
          <ArrowRight className="h-4 w-4" />
        </button>
      </motion.section>

      {/* ── Promo banner (app-like) ── */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.1, ease: EASE }}
        className="flex items-center gap-4 overflow-hidden rounded-[20px] bg-gradient-to-r from-[#1a1060] to-[#2d1b8a] p-4 text-white"
      >
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <LogoMark size={22} />
            <p className="text-[11px] font-bold text-white/60">পরীক্ষাঙ্গন</p>
          </div>
          <p className="mt-1.5 font-bangla text-[19px] font-extrabold leading-snug">
            সঠিক প্রস্তুতি,
            <br />
            <span className="text-[#FF5200]">নিশ্চিত সাফল্য</span>
          </p>
          <button
            onClick={() => goTab("exams")}
            className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-[#FF5200] px-4 py-2 text-[12px] font-extrabold text-white"
          >
            এখনই শুরু করুন <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="shrink-0 text-[52px] select-none">📱</div>
      </motion.div>

      {/* ── Quick access ── */}
      <motion.section
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.15, ease: EASE }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="h-5 w-1 rounded-full bg-[#FF5200]" />
            <h3 className="font-bangla text-[16px] font-extrabold text-[#161210]">দ্রুত অ্যাক্সেস</h3>
          </div>
          <button onClick={() => goTab("exams")} className="flex items-center gap-1 text-[13px] font-bold text-[#FF5200]">
            পরীক্ষা জোন <ChevronRight className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-3">
          {QUICK.map((q, i) => (
            <motion.button
              key={q.label}
              onClick={() => goTab(q.tab)}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.18 + i * 0.05, duration: 0.4, ease: EASE }}
              whileTap={{ scale: 0.94 }}
              className="flex flex-col items-center gap-2 rounded-[18px] bg-white p-4 shadow-sm ring-1 ring-black/5 transition-shadow hover:shadow-md"
            >
              <div className={`grid h-12 w-12 place-items-center rounded-[14px] ${q.bg}`}>
                <q.icon className={`h-6 w-6 ${q.iconColor}`} />
              </div>
              <p className="font-bangla text-[12.5px] font-bold text-[#161210]">{q.label}</p>
            </motion.button>
          ))}
        </div>
      </motion.section>

      {/* ── Streak tracker ── */}
      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.25, ease: EASE }}
        className="rounded-[20px] bg-[#FFF8ED] p-4 ring-1 ring-[#FFB300]/20"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[#FF5200]">
              <Flame className="h-5 w-5 text-white" fill="white" />
            </div>
            <div>
              <p className="font-bangla text-[13.5px] font-bold text-[#FF5200]">ধারাবাহিকতা</p>
              <p className="font-bangla text-[14px] font-extrabold text-[#161210]">
                {toBn(`${stats.streak}`)} দিন ধরে নিয়মিত প্র্যাকটিস করছেন!
              </p>
            </div>
          </div>
          <ChevronRight className="h-5 w-5 text-stone-400" />
        </div>
        <div className="mt-3 flex items-center gap-1.5">
          {(stats.weeklyStreak.length === 7 ? stats.weeklyStreak : Array(7).fill(false)).map((active, i) => (
            <div
              key={i}
              className={`h-2 flex-1 rounded-full transition-colors ${active ? "bg-[#FF5200]" : "bg-[#FFB300]/30"}`}
            />
          ))}
        </div>
        <p className="mt-1.5 text-[11px] font-semibold text-stone-400">গত ৭ দিন</p>
      </motion.section>

      {/* ── Leaderboard snapshot ── */}
      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3, ease: EASE }}
        className="rounded-[20px] bg-white p-4 ring-1 ring-black/6 shadow-sm"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[#EEF2FF]">
              <Trophy className="h-5.5 w-5.5 text-[#4F46E5]" />
            </div>
            <div>
              <p className="font-bangla text-[16px] font-extrabold text-[#161210]">লিডারবোর্ড</p>
              <p className="text-[12px] font-semibold text-stone-400">শীর্ষ পারফর্মার</p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-bangla text-[19px] font-extrabold text-[#4F46E5]">
              #{toBn(`${stats.rank}`)}
            </p>
            <p className="text-[11px] font-semibold text-stone-400">আপনার র‍্যাংক</p>
          </div>
        </div>

        <div className="mt-4 space-y-2.5">
          {leaders.slice(0, 3).map((l, i) => (
            <div key={l.uid} className="flex items-center gap-3 rounded-2xl bg-[#F8F9FA] px-3.5 py-2.5">
              <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-xl font-bangla text-[13px] font-extrabold ${RANK_MEDAL[i]}`}>
                {i === 0 && <Crown className="h-4 w-4" fill="currentColor" />}
                {i > 0 && toBn(`${i + 1}`)}
              </span>
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#DDD] text-[13px] font-bold text-white overflow-hidden">
                {l.photoURL
                  ? <img src={l.photoURL} alt="" className="h-full w-full object-cover" />
                  : l.name.charAt(0)
                }
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-bangla text-[14px] font-bold text-[#161210]">
                  {i === 0 && <Crown className="mr-1 inline h-3.5 w-3.5 text-[#FFD700]" fill="currentColor" />}
                  {l.name}
                </p>
                <p className="truncate text-[11.5px] font-semibold text-stone-400">{l.org}</p>
              </div>
              <div className="text-right">
                <p className="font-bangla text-[15px] font-extrabold text-[#161210]">
                  {toBn(l.points.toLocaleString("en-IN"))}
                </p>
                <p className="text-[10px] font-semibold text-stone-400">পয়েন্ট</p>
              </div>
            </div>
          ))}
        </div>

        {/* dots */}
        <div className="mt-3 flex justify-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <span key={i} className={`h-1.5 rounded-full ${i === 0 ? "w-4 bg-[#4F46E5]" : "w-1.5 bg-stone-200"}`} />
          ))}
        </div>

        <button
          onClick={() => goTab("leaderboard")}
          className="mt-3 flex w-full items-center justify-between rounded-2xl bg-[#F0F0FF] px-4 py-3"
        >
          <div className="flex items-center gap-2">
            <div className="grid h-8 w-8 place-items-center rounded-xl bg-[#4F46E5]">
              <UserRound className="h-4 w-4 text-white" />
            </div>
            <div className="text-left">
              <p className="font-bangla text-[14px] font-extrabold text-[#4F46E5]">তুমি (আপনি)</p>
              <p className="text-[11px] text-stone-500">Student</p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-bangla text-[16px] font-extrabold text-[#161210]">
              {toBn(`${stats.points.toLocaleString("en-IN")}`)}
            </p>
            <p className="text-[10px] font-semibold text-stone-400">পয়েন্ট</p>
          </div>
        </button>
      </motion.section>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   EXAM TAB (placeholder — links to real /exams)
═══════════════════════════════════════════════ */
function ExamsTab({ goTab }: { goTab: (t: string) => void }) {
  const items = [
    { label: "লাইভ মক এক্সাম", desc: "প্রতিদিন রাত ৯টা — সবার সাথে", icon: Radio, color: "bg-[#FF5200]", chip: "লাইভ আজকে" },
    { label: "মডেল টেস্ট", desc: "পেপার-ওয়াইজ ফুল সিলেবাস", icon: ClipboardList, color: "bg-[#4F46E5]", chip: "HSC · SSC" },
    { label: "AI অ্যাডাপটিভ কুইজ", desc: "তোমার দুর্বলতা অনুযায়ী প্রশ্ন", icon: BrainCircuit, color: "bg-[#0EA5E9]", chip: "স্মার্ট" },
    { label: "অফলাইন প্যাক", desc: "ইন্টারনেট ছাড়াই চর্চা", icon: WifiOff, color: "bg-[#10B981]", chip: "Pro" },
  ];
  return (
    <div className="space-y-4 pb-32">
      <div className="flex items-center gap-2">
        <span className="h-5 w-1 rounded-full bg-[#FF5200]" />
        <h2 className="font-bangla text-[20px] font-extrabold text-[#161210]">পরীক্ষা জোন</h2>
      </div>
      <div className="space-y-3">
        {items.map((it, i) => (
          <motion.button
            key={it.label}
            onClick={() => goTab("live")}
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.07, duration: 0.45, ease: EASE }}
            whileTap={{ scale: 0.97 }}
            className="flex w-full items-center gap-4 rounded-[20px] bg-white p-4 text-left shadow-sm ring-1 ring-black/6 transition-shadow hover:shadow-md"
          >
            <div className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl ${it.color}`}>
              <it.icon className="h-6 w-6 text-white" />
            </div>
            <div className="flex-1">
              <p className="font-bangla text-[15px] font-bold text-[#161210]">{it.label}</p>
              <p className="text-[12.5px] text-stone-500">{it.desc}</p>
            </div>
            <div className="flex flex-col items-end gap-1.5">
              <span className="rounded-full bg-[#FFF0E6] px-2.5 py-0.5 text-[10.5px] font-bold text-[#FF5200]">{it.chip}</span>
              <ChevronRight className="h-4.5 w-4.5 text-stone-300" />
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   FEATURE HUB TABS (qbank/flash/battle/saved/wrong/live)
═══════════════════════════════════════════════ */
function FeatureHubTab({
  title,
  subtitle,
  items,
}: {
  title: string;
  subtitle: string;
  items: { icon: string; title: string; desc: string; chip?: string }[];
}) {
  return (
    <div className="space-y-4 pb-32">
      <div className="flex items-center gap-2">
        <span className="h-5 w-1 rounded-full bg-[#FF5200]" />
        <h2 className="font-bangla text-[20px] font-extrabold text-[#161210]">{title}</h2>
      </div>
      <p className="text-[13px] text-stone-500">{subtitle}</p>
      <div className="space-y-3">
        {items.map((it, i) => (
          <motion.div
            key={it.title}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06, duration: 0.4, ease: EASE }}
            className="flex items-start gap-3 rounded-[18px] bg-white p-4 ring-1 ring-black/6 shadow-sm"
          >
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[#FFF0E6] text-[20px]">
              {it.icon}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <p className="font-bangla text-[14.5px] font-bold text-[#161210]">{it.title}</p>
                {it.chip && <span className="rounded-full bg-[#FFF0E6] px-2 py-0.5 text-[10px] font-bold text-[#FF5200]">{it.chip}</span>}
              </div>
              <p className="mt-1 text-[12.5px] leading-relaxed text-stone-500">{it.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   PRACTICE TAB
═══════════════════════════════════════════════ */
function PracticeTab() {
  const subjects = [
    { name: "পদার্থবিজ্ঞান", icon: "⚛️", color: "bg-blue-50 ring-blue-100" },
    { name: "রসায়ন", icon: "🧪", color: "bg-green-50 ring-green-100" },
    { name: "উচ্চতর গণিত", icon: "📐", color: "bg-purple-50 ring-purple-100" },
    { name: "জীববিজ্ঞান", icon: "🌿", color: "bg-emerald-50 ring-emerald-100" },
    { name: "বাংলা", icon: "📖", color: "bg-orange-50 ring-orange-100" },
    { name: "ইংরেজি", icon: "🔤", color: "bg-sky-50 ring-sky-100" },
    { name: "ICT", icon: "💻", color: "bg-indigo-50 ring-indigo-100" },
    { name: "সাধারণ জ্ঞান", icon: "🌍", color: "bg-yellow-50 ring-yellow-100" },
  ];
  return (
    <div className="space-y-4 pb-32">
      <div className="flex items-center gap-2">
        <span className="h-5 w-1 rounded-full bg-[#FF5200]" />
        <h2 className="font-bangla text-[20px] font-extrabold text-[#161210]">বিষয় বেছে চর্চা করো</h2>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {subjects.map((s, i) => (
          <motion.button
            key={s.name}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06, duration: 0.4, ease: EASE }}
            whileTap={{ scale: 0.95 }}
            className={`flex items-center gap-3 rounded-[18px] p-4 text-left ring-1 transition-all active:scale-95 ${s.color}`}
          >
            <span className="text-[26px]">{s.icon}</span>
            <span className="font-bangla text-[14px] font-bold text-[#161210]">{s.name}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   HISTORY TAB
═══════════════════════════════════════════════ */
function HistoryTab({ stats }: { stats: UserStats }) {
  const fakeHistory = [
    { title: "পদার্থবিজ্ঞান মক #৪১", score: 88, rank: 451, date: "আজ", correct: 22, total: 25 },
    { title: "রসায়ন মডেল টেস্ট", score: 76, rank: 812, date: "গতকাল", correct: 19, total: 25 },
    { title: "ICT সাপ্তাহিক টেস্ট", score: 92, rank: 118, date: "২ দিন আগে", correct: 23, total: 25 },
    { title: "উচ্চতর গণিত ১ম পত্র", score: 64, rank: 1240, date: "৩ দিন আগে", correct: 16, total: 25 },
  ];
  return (
    <div className="space-y-4 pb-32">
      <div className="flex items-center gap-2">
        <span className="h-5 w-1 rounded-full bg-[#FF5200]" />
        <h2 className="font-bangla text-[20px] font-extrabold text-[#161210]">পরীক্ষার ইতিহাস</h2>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "মোট পরীক্ষা", val: toBn(`${stats.totalExams}`) },
          { label: "সঠিক হার", val: `${toBn(`${stats.accuracy}`)}%` },
          { label: "পয়েন্ট", val: toBn(`${stats.points.toLocaleString("en-IN")}`) },
        ].map((s) => (
          <div key={s.label} className="rounded-[16px] bg-white p-3 text-center ring-1 ring-black/6 shadow-sm">
            <p className="font-bangla text-[20px] font-extrabold text-[#FF5200]">{s.val}</p>
            <p className="mt-0.5 text-[10.5px] font-semibold text-stone-500">{s.label}</p>
          </div>
        ))}
      </div>
      <div className="space-y-2.5">
        {fakeHistory.map((h, i) => (
          <motion.div
            key={h.title}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07, duration: 0.4, ease: EASE }}
            className="flex items-center gap-4 rounded-[18px] bg-white p-4 ring-1 ring-black/6 shadow-sm"
          >
            <div className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl ${h.score >= 80 ? "bg-[#E8F5E9]" : h.score >= 60 ? "bg-[#FFF8E1]" : "bg-[#FFEBEE]"}`}>
              <p className={`font-bangla text-[16px] font-extrabold ${h.score >= 80 ? "text-[#2E7D32]" : h.score >= 60 ? "text-[#F57F17]" : "text-[#C62828]"}`}>
                {toBn(`${h.score}`)}%
              </p>
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate font-bangla text-[14px] font-bold text-[#161210]">{h.title}</p>
              <p className="text-[12px] text-stone-500">{toBn(`${h.correct}`)}/{toBn(`${h.total}`)} সঠিক · {h.date}</p>
            </div>
            <div className="text-right">
              <p className="text-[12px] font-bold text-[#4F46E5]">#{toBn(`${h.rank}`)}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   PROFILE TAB
═══════════════════════════════════════════════ */
function ProfileTab({ name, email, track, stats }: { name: string; email: string; track: string; stats: UserStats }) {
  const { logOut } = useAuth();
  const menuItems = [
    { icon: Settings, label: "সেটিংস", color: "bg-stone-100 text-stone-600" },
    { icon: Star, label: "Pro প্ল্যানে আপগ্রেড করো", color: "bg-[#FFF0E6] text-[#FF5200]", highlight: true },
    { icon: Check, label: "প্রাইভেসি নীতি", color: "bg-stone-100 text-stone-600" },
    { icon: Check, label: "টার্মস অব সার্ভিস", color: "bg-stone-100 text-stone-600" },
  ];
  return (
    <div className="space-y-4 pb-32">
      {/* Avatar card */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="relative overflow-hidden rounded-[24px] bg-gradient-to-br from-[#FF5200] to-[#FF8C42] p-5 text-white shadow-[0_14px_36px_-12px_rgba(255,82,0,0.5)]"
      >
        <div className="pointer-events-none absolute -right-6 -top-6 h-32 w-32 rounded-full bg-white/10" />
        <div className="flex items-center gap-4">
          <div className="grid h-16 w-16 place-items-center rounded-full bg-white/20 font-bangla text-[26px] font-extrabold text-white ring-2 ring-white/40">
            {name.trim().charAt(0)}
          </div>
          <div>
            <p className="font-bangla text-[20px] font-extrabold">{name}</p>
            <p className="text-[12.5px] text-white/70">{email}</p>
            <span className="mt-1.5 inline-block rounded-full bg-white/20 px-3 py-0.5 text-[11px] font-bold">
              ট্র্যাক: {track}
            </span>
          </div>
        </div>
        <div className="mt-4 flex gap-3">
          {[
            { v: toBn(`${stats.points.toLocaleString("en-IN")}`), l: "পয়েন্ট" },
            { v: `#${toBn(`${stats.rank}`)}`, l: "র‍্যাংক" },
            { v: `${toBn(`${stats.streak}`)}🔥`, l: "স্ট্রিক" },
          ].map((s) => (
            <div key={s.l} className="flex-1 rounded-2xl bg-white/15 p-2.5 text-center">
              <p className="font-bangla text-[15px] font-extrabold">{s.v}</p>
              <p className="text-[10px] text-white/70">{s.l}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Menu items */}
      <div className="space-y-2.5">
        {menuItems.map((item, i) => (
          <motion.button
            key={item.label}
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 + i * 0.07, duration: 0.4, ease: EASE }}
            className={`flex w-full items-center gap-4 rounded-[18px] p-4 text-left ring-1 transition-all ${
              item.highlight ? "bg-[#FFF5F0] ring-[#FF5200]/20" : "bg-white ring-black/6"
            } shadow-sm`}
          >
            <div className={`grid h-10 w-10 place-items-center rounded-2xl ${item.color}`}>
              <item.icon className="h-5 w-5" />
            </div>
            <span className={`font-bangla text-[14.5px] font-bold ${item.highlight ? "text-[#FF5200]" : "text-[#161210]"}`}>
              {item.label}
            </span>
            <ChevronRight className="ml-auto h-4.5 w-4.5 text-stone-300" />
          </motion.button>
        ))}

        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.38 }}
          onClick={async () => {
            await logOut();
            window.location.hash = "#/";
          }}
          className="flex w-full items-center gap-4 rounded-[18px] bg-white p-4 text-left ring-1 ring-red-100 shadow-sm"
        >
          <div className="grid h-10 w-10 place-items-center rounded-2xl bg-red-50">
            <LogOut className="h-5 w-5 text-red-500" />
          </div>
          <span className="font-bangla text-[14.5px] font-bold text-red-500">লগ আউট</span>
        </motion.button>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   LEADERBOARD TAB
═══════════════════════════════════════════════ */
function LeaderboardTab({ leaders, myRank, myName }: { leaders: LeaderEntry[]; myRank: number; myName: string }) {
  return (
    <div className="space-y-4 pb-32">
      <div className="flex items-center gap-2">
        <span className="h-5 w-1 rounded-full bg-[#FF5200]" />
        <h2 className="font-bangla text-[20px] font-extrabold text-[#161210]">সাপ্তাহিক লিডারবোর্ড</h2>
      </div>

      {/* My rank banner */}
      <div className="flex items-center justify-between rounded-[18px] bg-[#4F46E5] px-4 py-3 text-white">
        <p className="font-bangla text-[14px] font-bold">আপনার অবস্থান</p>
        <p className="font-bangla text-[20px] font-extrabold">#{toBn(`${myRank}`)}</p>
      </div>

      <div className="space-y-2.5">
        {leaders.map((l, i) => (
          <motion.div
            key={l.uid}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06, duration: 0.4, ease: EASE }}
            className={`flex items-center gap-3 rounded-[18px] p-3.5 ring-1 ${
              l.name === myName ? "bg-[#EEF2FF] ring-[#4F46E5]/30" : "bg-white ring-black/6"
            } shadow-sm`}
          >
            <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl font-bangla text-[13px] font-extrabold ${
              i < 3 ? RANK_MEDAL[i] : "bg-stone-100 text-stone-600"
            }`}>
              {i < 3 ? (i === 0 ? <Crown className="h-4 w-4" fill="currentColor" /> : toBn(`${i + 1}`)) : toBn(`${i + 1}`)}
            </span>
            <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full bg-stone-200 text-[14px] font-bold text-white">
              {l.photoURL ? <img src={l.photoURL} alt="" className="h-full w-full object-cover" /> : l.name.charAt(0)}
            </div>
            <div className="min-w-0 flex-1">
              <p className={`truncate font-bangla text-[14px] font-bold ${l.name === myName ? "text-[#4F46E5]" : "text-[#161210]"}`}>
                {l.name} {l.name === myName && "(আপনি)"}
              </p>
              <p className="truncate text-[11.5px] text-stone-400">{l.org}</p>
            </div>
            <div className="text-right">
              <p className="font-bangla text-[15px] font-extrabold text-[#161210]">
                {toBn(l.points.toLocaleString("en-IN"))}
              </p>
              <p className="text-[10px] text-stone-400">পয়েন্ট</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   MAIN DASHBOARD SHELL
═══════════════════════════════════════════════ */
const DEFAULT_STATS: UserStats = {
  points: 0, totalExams: 0, accuracy: 0, streak: 0, rank: 999,
  weeklyStreak: Array(7).fill(false),
};

const MOCK_LEADERS: LeaderEntry[] = [
  { uid: "1", name: "সৌরভ", org: "ঢাকা কলেজ", points: 1000000 },
  { uid: "2", name: "Tasnim", org: "Student", points: 50000 },
  { uid: "3", name: "Sourav", org: "MGC", points: 26755 },
  { uid: "4", name: "Ayesha", org: "Viqarunnisa", points: 18420 },
  { uid: "5", name: "Rahim", org: "Notre Dame", points: 12300 },
];

export default function Dashboard() {
  const { user, profile, loading } = useAuth();
  const [tab, setTab] = useState("home");
  const [stats, setStats] = useState<UserStats>(DEFAULT_STATS);
  const [leaders, setLeaders] = useState<LeaderEntry[]>(MOCK_LEADERS);
  const contentRef = useRef<HTMLDivElement>(null);

  /* Redirect if not logged in */
  useEffect(() => {
    if (!loading && !user) window.location.hash = "#/login";
  }, [loading, user]);

  /* Parse hash: #/dashboard/<tab> */
  useEffect(() => {
    const syncTab = () => {
      const parts = window.location.hash.split("/");
      const t = parts[2] || "home";
      setTab(["home","exams","practice","history","leaderboard","profile"].includes(t) ? t : "home");
    };
    syncTab();
    window.addEventListener("hashchange", syncTab);
    return () => window.removeEventListener("hashchange", syncTab);
  }, []);

  /* Load stats from RTDB */
  useEffect(() => {
    if (!user) return;
    const statsRef = ref(db, `users/${user.uid}/stats`);
    const unsub = onValue(statsRef, (snap) => {
      if (snap.exists()) {
        const d = snap.val();
        setStats({
          points: d.points ?? 0,
          totalExams: d.totalExams ?? 0,
          accuracy: d.accuracy ?? 0,
          streak: d.streak ?? 0,
          rank: d.rank ?? 999,
          weeklyStreak: d.weeklyStreak ?? Array(7).fill(false),
        });
      }
    });
    return () => unsub();
  }, [user]);

  /* Load leaderboard from RTDB */
  useEffect(() => {
    const lbRef = ref(db, "leaderboard");
    get(lbRef).then((snap) => {
      if (snap.exists()) {
        const raw = snap.val() as Record<string, { name: string; org?: string; points: number; photoURL?: string }>;
        const sorted = Object.entries(raw)
          .map(([uid, v]) => ({ uid, name: v.name, org: v.org ?? "Student", points: v.points, photoURL: v.photoURL }))
          .sort((a, b) => b.points - a.points)
          .slice(0, 8);
        if (sorted.length) setLeaders(sorted);
      }
    }).catch(() => {/* keep mock */});
  }, []);

  const goTab = (t: string) => {
    window.location.hash = `#/dashboard/${t}`;
    contentRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (loading || !user) return <Splash />;

  const name = profile?.name || user.displayName || "শিক্ষার্থী";
  const email = user.email ?? "";
  const track = profile?.track ?? "HSC";

  return (
    <div className="flex h-[100dvh] flex-col overflow-hidden bg-[#F5F5F5]">
      {/* ── Top bar ── */}
      <header className="z-30 flex shrink-0 items-center justify-between bg-white px-4 py-3 shadow-[0_1px_0_rgba(0,0,0,0.06)]">
        <div className="flex items-center gap-2">
          {/* Streak pill */}
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#FFF0E6] ring-2 ring-[#FF5200]/30">
            <Flame className="h-4 w-4 text-[#FF5200]" fill="#FF5200" />
          </div>
          <div className="h-2 w-2 rounded-full bg-stone-300" />
        </div>

        <h1 className="font-bangla text-[22px] font-extrabold tracking-tight text-[#161210]">পরীক্ষাঙ্গন</h1>

        <button
          onClick={() => goTab("profile")}
          className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full bg-stone-200 ring-2 ring-[#FF5200]/40"
          aria-label="Profile"
        >
          {user.photoURL
            ? <img src={user.photoURL} alt="" className="h-full w-full object-cover" />
            : <span className="font-bangla text-[15px] font-bold text-stone-600">{name.charAt(0)}</span>
          }
        </button>
      </header>

      {/* ── Scrollable content ── */}
      <main ref={contentRef} className="flex-1 overflow-y-auto overscroll-contain px-4 pt-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.28, ease: EASE }}
          >
            {tab === "home" && <HomeTab name={name} stats={stats} leaders={leaders} goTab={goTab} />}
            {tab === "exams" && <ExamsTab goTab={goTab} />}
            {tab === "practice" && <PracticeTab />}
            {tab === "history" && <HistoryTab stats={stats} />}
            {tab === "leaderboard" && <LeaderboardTab leaders={leaders} myRank={stats.rank} myName={name} />}
            {tab === "profile" && <ProfileTab name={name} email={email} track={track} stats={stats} />}
            {tab === "qbank" && <FeatureHubTab title="প্রশ্ন ব্যাংক" subtitle="অধ্যায়ভিত্তিক সাজানো প্রশ্ন, উত্তর আর ব্যাখ্যা।" items={[
              { icon: "📘", title: "পদার্থবিজ্ঞান", desc: "বল, গতি, কাজ, শক্তি — অধ্যায়ভিত্তিক MCQ ও ব্যাখ্যা।", chip: "HSC" },
              { icon: "🧪", title: "রসায়ন", desc: "অ্যাসিড-ক্ষার, জৈব যৌগ, পর্যায় সারণি ও রিয়াকশনভিত্তিক প্রশ্ন।" },
              { icon: "📐", title: "উচ্চতর গণিত", desc: "ম্যাট্রিক্স, বীজগাণিতিক রাশি, সরলরেখা, অন্তরকলন।" },
              { icon: "🌿", title: "জীববিজ্ঞান", desc: "কোষ, উদ্ভিদ, প্রাণী, জেনেটিক্স — ব্যাখ্যাসহ।" },
            ]} />}
            {tab === "flash" && <FeatureHubTab title="ফ্ল্যাশ কার্ড" subtitle="যেগুলো বারবার ভুল হচ্ছে, সেগুলো মনে রাখার শর্ট নোট।" items={[
              { icon: "⭐", title: "Formula Burst", desc: "গণিত ও পদার্থের গুরুত্বপূর্ণ সূত্রগুলো ৩০ সেকেন্ডে রিভিশন।" },
              { icon: "🧠", title: "Definition Deck", desc: "সংজ্ঞা, পার্থক্য, ব্যতিক্রম ও ছোট facts।", chip: "দৈনিক" },
              { icon: "🔁", title: "Spaced Revision", desc: "যা আজ দেখলে কাল আবার, তারপর ৩ দিন পরে ফেরত আসবে।" },
            ]} />}
            {tab === "battle" && <FeatureHubTab title="কুইজ ব্যাটল" subtitle="বন্ধুদের সাথে ১v১ বা async challenge — পয়েন্ট জিতো, র‍্যাংক বাড়াও।" items={[
              { icon: "⚔️", title: "১v১ লাইভ ব্যাটল", desc: "একই সময়ে ১০ প্রশ্ন — কে আগে, কে বেশি সঠিক?", chip: "Live" },
              { icon: "📨", title: "Invite Link", desc: "বন্ধুকে লিংক পাঠিয়ে পরে খেলতে দাও — async battle mode।" },
              { icon: "🏆", title: "Battle History", desc: "কত জিতেছ, কত হেরেছ, কোন বিষয়ে এগিয়ে — সব হিসাব।" },
            ]} />}
            {tab === "saved" && <FeatureHubTab title="সেভড প্রশ্ন" subtitle="পরে পড়ব ভেবে তুলে রাখা প্রিয় প্রশ্নগুলো।" items={[
              { icon: "🔖", title: "বোর্ড প্রশ্ন সংগ্রহ", desc: "যে প্রশ্নগুলো পরে আবার অনুশীলন করতে চাও।" },
              { icon: "📂", title: "চ্যাপ্টার অনুযায়ী সেভ", desc: "পদার্থ / রসায়ন / গণিত আলাদা ফোল্ডারে।" },
            ]} />}
            {tab === "wrong" && <FeatureHubTab title="ভুল প্রশ্ন" subtitle="যেখানে নম্বর হারাচ্ছো — সেগুলোই ফেরত এনে ঠিক করাবে।" items={[
              { icon: "❌", title: "Recent Mistakes", desc: "সর্বশেষ পরীক্ষায় ভুল হওয়া প্রশ্নগুলো একসাথে।" },
              { icon: "🎯", title: "Retry Mode", desc: "শুধু ভুল প্রশ্ন নিয়ে আলাদা ছোট কুইজ।", chip: "Recommended" },
              { icon: "📊", title: "Mistake Pattern", desc: "কোন অধ্যায়ে বেশি ভুল, কোন ধরনের ভুল — রিপোর্ট আকারে।" },
            ]} />}
            {tab === "live" && <FeatureHubTab title="লাইভ মক এক্সাম" subtitle="সবার সাথে একই সময়ে পরীক্ষা দিয়ে মেধা তালিকায় ওঠো।" items={[
              { icon: "📡", title: "আজ রাত ৯টার লাইভ মক", desc: "২৫ প্রশ্ন · ২৫ মিনিট · instant merit rank", chip: "Live now" },
              { icon: "⏱️", title: "টাইম-আটাক মোড", desc: "প্রশ্নপ্রতি নির্দিষ্ট সময় — চাপের মধ্যে সঠিক উত্তর।" },
              { icon: "🏅", title: "Exam Result", desc: "র‍্যাংক, নির্ভুলতা, সময় বিশ্লেষণ — সাথে সাথে।" },
            ]} />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* ── Bottom nav ── */}
      <nav className="z-30 shrink-0 border-t border-black/6 bg-white" aria-label="ড্যাশবোর্ড নেভিগেশন">
        <div className="mx-auto grid max-w-md grid-cols-5">
          {NAV_TABS.map((t) => {
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => goTab(t.id)}
                aria-current={active ? "page" : undefined}
                className="relative flex flex-col items-center gap-0.5 py-2.5 transition-colors"
              >
                {active && (
                  <motion.span
                    layoutId="bottom-indicator"
                    className="absolute top-0 h-[3px] w-10 rounded-full bg-[#FF5200]"
                    transition={{ type: "spring", stiffness: 500, damping: 36 }}
                  />
                )}
                <t.icon
                  className={`h-[22px] w-[22px] transition-colors ${active ? "text-[#FF5200]" : "text-stone-400"}`}
                  strokeWidth={active ? 2.5 : 1.8}
                />
                <span className={`text-[10.5px] font-bold transition-colors ${active ? "text-[#FF5200]" : "text-stone-400"}`}>
                  {t.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
