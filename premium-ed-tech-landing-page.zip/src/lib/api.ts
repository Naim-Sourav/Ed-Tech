/* ─────────────────────────────────────────────
   Backend API layer (optional)
   DB URI / Mongo password কখনো frontend-এ ব্যবহার করা যাবে না.
   শুধু backend HTTP endpoint call করার জন্য.
   Set VITE_API_BASE_URL in your deployment env.
   ───────────────────────────────────────────── */

const API_BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, "") || "";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  if (!API_BASE) throw new Error("API base URL is not configured.");
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
    ...init,
  });
  if (!res.ok) throw new Error(`API request failed: ${res.status}`);
  return res.json() as Promise<T>;
}

export const backendApi = {
  enabled: Boolean(API_BASE),

  getQuestionBySlug: (slug: string) => request(`/api/questions/slug/${encodeURIComponent(slug)}`),
  getPastPaperQuiz: (examRef: string) => request(`/api/quiz/past-paper/${encodeURIComponent(examRef)}`),
  generateQuizFromDb: (payload: unknown) => request(`/api/quiz/generate-from-db`, { method: "POST", body: JSON.stringify(payload) }),
  getSyllabusStats: () => request(`/api/quiz/syllabus-stats`),

  syncUser: (payload: unknown) => request(`/api/users/sync`, { method: "POST", body: JSON.stringify(payload) }),
  getUserStats: (userId: string) => request(`/api/users/${encodeURIComponent(userId)}/stats`),
  submitExamResult: (userId: string, payload: unknown) => request(`/api/users/${encodeURIComponent(userId)}/exam-results`, { method: "POST", body: JSON.stringify(payload) }),

  getStudySessions: (userId: string) => request(`/api/study/sessions/${encodeURIComponent(userId)}`),
  createStudyTarget: (payload: unknown) => request(`/api/study/targets`, { method: "POST", body: JSON.stringify(payload) }),
};
